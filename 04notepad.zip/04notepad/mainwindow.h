#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include <QMenuBar>
#include <QMenu>
#include <QFileDialog>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    bool isChanged;
    QString fileNameString;//文件名字
    QString file_name;
    QTextEdit *text1;//这里是一个指针不要忘记了。总是在这个地方出现问题。
    QFileInfo fileinfo;
    QMenu *fileMenu;//文件下拉菜单

    QAction *newFile;//新建文件。
    QAction *openFile;//打开文件。
    QAction *saveFile;//保存文件。
    QAction *quitFile;//推出。

    QMenu *editMenu;//编辑菜单
    QAction *copyEdit;
    QAction *pasteEdit;
    QAction *cutEdit;
    QAction *undoEdit;
    QAction *allSelectEdit;

    QMenu *helpMenu;//帮助菜单
    QAction *aboutSoftware;
    QAction *howToUse;

    Ui::MainWindow *ui;

private slots:
    void on_new();
    void on_open();
    void on_save();
    void on_quit();

    void on_copy();
    void on_paste();
    void on_cut();
    void on_undo();
    void on_allSelect();

    void on_howToUse();
    void on_aboutSoftware();
    void on_changed();
    void on_shu();


};

#endif // MAINWINDOW_H
