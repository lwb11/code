#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QDebug>
#include <QFileInfo>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    /********************************************************************/
    /*存在的bug：不能判断已有的文件内容是否进行了修改，默认已保存过，导致新增内容丢失*/
    /********************************************************************/
    ui->setupUi(this);

    isChanged = false;
    char bufSave[1024];
    text1 = new QTextEdit;//中央编辑区域的实例化
    this->setCentralWidget(text1);//设置到中央编辑页面。
    text1->setFontPointSize(16);//修改字体大小。
    resize(800,600);


    //添加文件下拉菜单
    fileMenu = this->menuBar()->addMenu("文件");

    //为下拉菜单添加文件项：
    newFile = new QAction("新建",this);//实例化
    newFile->setShortcut(tr("CTRL+N"));
    fileMenu->addAction(newFile);//添加到显示
    connect(newFile,SIGNAL(triggered()),this,SLOT(on_new()));//为当前这个文件项添加一个出发事件，当前窗体响应，执行函数为on_new().

    openFile = new QAction("打开",this);//实例化
    openFile->setShortcut(tr("CTRL+O"));
    fileMenu->addAction(openFile);
    connect(openFile,SIGNAL(triggered()),this,SLOT(on_open()));

    saveFile = new QAction("保存",this);
    saveFile->setShortcut(tr("CTRL+S"));
    fileMenu->addAction(saveFile);
    connect(saveFile,SIGNAL(triggered()),this,SLOT(on_save()));

    quitFile = new QAction("退出",this);
    quitFile->setShortcut(tr("CTRL+Q"));
    fileMenu->addAction(quitFile);
    connect(quitFile,SIGNAL(triggered()),this,SLOT(on_quit()));


    editMenu =this->menuBar()->addMenu("编辑");

    copyEdit = new QAction("复制",this);
    copyEdit->setShortcut(tr("CTRL+C"));
    editMenu->addAction(copyEdit);
    connect(copyEdit,SIGNAL(triggered()),this,SLOT(on_copy()));

    pasteEdit = new QAction("粘贴",this);
    pasteEdit->setShortcut(tr("CTRL+V"));
    editMenu->addAction(pasteEdit);
    connect(pasteEdit,SIGNAL(triggered()),this,SLOT(on_paste()));

    cutEdit = new QAction("剪切",this);
    cutEdit->setShortcut(tr("CTRL+X"));
    editMenu->addAction(cutEdit);
    connect(cutEdit,SIGNAL(triggered()),this,SLOT(on_cut()));

    undoEdit = new QAction("撤销",this);
    undoEdit->setShortcut(tr("CTRL+Z"));
    editMenu->addAction(undoEdit);
    connect(undoEdit,SIGNAL(triggered()),this,SLOT(on_undo()));

    allSelectEdit = new QAction("全选",this);
    allSelectEdit->setShortcut(tr("CTRL+A"));
    editMenu->addAction(allSelectEdit);
    connect(allSelectEdit,SIGNAL(triggered()),this,SLOT(on_allSelect()));

    helpMenu = this->menuBar()->addMenu("帮助");

    aboutSoftware = new QAction("关于软件",this);
    helpMenu->addAction(aboutSoftware);
    connect(aboutSoftware,SIGNAL(triggered()),this,SLOT(on_aboutSoftware()));

    howToUse = new QAction("如何使用",this);
    helpMenu->addAction(howToUse);
    connect(howToUse,SIGNAL(triggered()),this,SLOT(on_howToUse()));

    connect(text1,SIGNAL(textChanged()),this,SLOT(on_changed()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_new()
{
    if(text1->document()->isEmpty()){   //判断文本内容是否为空
        text1->setText("");//为空，直接新建,把文本内容置空。
    }else{
        if(QMessageBox::Yes == QMessageBox::question(this,QString("提示"),QString ("文件未保存是否新建文档？"),QMessageBox::Yes | QMessageBox::No,QMessageBox::Yes)){
            text1->setText("");//选择不保存文档直接新建，文本内容置空。
        }else{                 //选择保存
            QFileInfo file("/home/li/linux/qt_tool/qt/qt_licheng/build-04notepad-Desktop_Qt_5_9_5_GCC_64bit-Debug/file");
            if(file.exists()==false){//否则判断该文件是否存在
                on_save();//不存在，进行保存操作
//            }else{
//                QMessageBox::information(this,"提示","文件已保存");
//                text1->setText("");//否则直接新建
            }
            on_save();
        }
    }
}

void MainWindow::on_open()
{
    if(text1->document()->isEmpty()){
//        QMessageBox::information(this,"提示","文件尚未保存");
        fileNameString = QFileDialog::getOpenFileName(this,"打开","/home/li/liunx/qt_tool/qt/qt_licheng/build-04notepad-Desktop_Qt_5_9_5_GCC_64bit-Debug/file");//当前窗体，打开文件的对话框的标题是：“打开”
        if(fileNameString==NULL){
            return ;
        }
//        FILE *pf = fopen(fileNameString.toStdString().data(),"r+");//可读可写的方式打开。
//        if(pf==NULL)
//            return ;
//        char buf[1024];
//        QString str;
//        while(!feof(pf)){
//            fgets(buf,sizeof(buf),pf);
//            str+=buf;
//        }

//        text1->setText(str);
//        fclose(pf);
        on_shu();
    }else{

        QMessageBox::warning(this,"警告！","文件未保存");
        on_save();
    }

}

void MainWindow::on_save()
{
    fileNameString = QFileDialog::getSaveFileName(this,"保存","/home/li/linux/qt_tool/qt/qt_licheng/build-04notepad-Desktop_Qt_5_9_5_GCC_64bit-Debug/file");
    fileinfo = QFileInfo(fileNameString);
    file_name = fileinfo.fileName();//获取保存的文件的文件名
    qDebug()<<file_name;    //打印文件名
    if(fileNameString==NULL)
        return ;
    FILE *pf = fopen(fileNameString.toStdString().data(),"w+");
    if(pf==NULL)
        return ;

    QString str = text1->toPlainText();
    fputs(str.toStdString().data(),pf);
    fclose(pf);
    isChanged = true;

}

void MainWindow::on_quit()
{
    if(text1->document()->isEmpty()){
        this->close();
    }else{
        QFileInfo file("/home/li/linux/qt_tool/qt/qt_licheng/build-04notepad-Desktop_Qt_5_9_5_GCC_64bit-Debug/file");
        if(file.exists()==false){
            qDebug()<<"文件不存在";
            on_save();//进行保存操作
        }
        else{
            qDebug()<<"文件存在";
//            if(str)
            this->close();//不保存直接退出
        }
    }
//        if(QMessageBox::No == QMessageBox::question(this,QString("提示"),QString ("是否保存修改？"),QMessageBox::Yes | QMessageBox::No,QMessageBox::Yes)){
//
//        }else{
//
//        }

}

void MainWindow::on_copy()
{
    text1->copy();
}

void MainWindow::on_paste()
{
    text1->paste();
}

void MainWindow::on_cut()
{
    text1->cut();
}

void MainWindow::on_undo()
{
    text1->undo();
}

void MainWindow::on_allSelect()
{
    text1->selectAll();
}

void MainWindow::on_howToUse()
{
    QMessageBox::information(this,"如何使用","同记事本基本相同");
}

void MainWindow::on_aboutSoftware()
{
    QMessageBox::information(this,"关于软件","Modify By : 李文飚");
}

void MainWindow::on_shu()
{
    FILE *pf = fopen(fileNameString.toStdString().data(),"r+");//可读可写的方式打开。
    if(pf==NULL)
        return ;
    char buf[1024];
    QString str;
    while(!feof(pf)){
        fgets(buf,sizeof(buf),pf);
        str+=buf;
    }

    text1->setText(str);
    fclose(pf);

}

void MainWindow::on_changed()
{
    isChanged = true;
}


