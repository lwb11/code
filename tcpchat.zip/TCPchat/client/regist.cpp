#include "regist.h"
#include "ui_regist.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>
#include <QVariantList>

regist::regist(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::regist)
{
    ui->setupUi(this);

    setWindowTitle("注册");

    ui->lineName->setPlaceholderText("请输入用户名");
    ui->lineNum->setPlaceholderText("请输入密码");
    ui->lineQuestion->setPlaceholderText("请确认密码");
}

regist::~regist()
{
    delete ui;
}

void regist::on_btnReg_clicked()
{
    QString user;
    QString pwd;
    QString qes;
    user=ui->lineName->text();
    pwd=ui->lineNum->text();
    qes=ui->lineQuestion->text();
    if(user==""){QMessageBox::warning(this,"","用户名不能为空！");}
    else if(pwd==""){QMessageBox::warning(this,"","密码不能为空！");}
    else if(qes==""){QMessageBox::warning(this,"","确认密码不能为空！");}
    else if(pwd!=qes){QMessageBox::warning(this,"","密码输入不一致！");}
    else{
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection")){db=QSqlDatabase::database("qt_sql_default_connection");}
        else{
            db=QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("users.db");
        db.open();

        QSqlQuery query(db);

        QString i=QString("insert into users values('%1','%2')").arg(user).arg(pwd);
        QString s=QString("select*from users where username='%1'").arg(user);
//        QSqlQuery query(db);
        if(query.exec(s)&&query.first()){
           QMessageBox::warning(this,"","用户名重复！");
        }
        else if(query.exec(i)){
            QMessageBox::information(this,"","注册成功！\n请重新登录");

            query.exec("select * from users");

            while(query.next())
            {
                //取出当前行的内容
                qDebug() << query.value("username").toString()
                         << query.value("pwd").toInt();
            }
        }

     db.close();

    }
}

void regist::on_btnLogin_clicked()
{
    emit this->back1();
}

void regist::on_btnQuit_clicked()
{
    ui->lineName->clear();
    ui->lineNum->clear();
    ui->lineQuestion->clear();

    emit this->back1();
}
