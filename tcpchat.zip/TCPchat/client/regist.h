#ifndef REGIST_H
#define REGIST_H

#include <QWidget>
#include "regist.h"
#include "login.h"

namespace Ui {
class regist;
}

class regist : public QWidget
{
    Q_OBJECT

public:
    explicit regist(QWidget *parent = 0);
    ~regist();


signals:
    void back1();

private slots:
    void on_btnReg_clicked();

    void on_btnLogin_clicked();

    void on_btnQuit_clicked();

private:
    Ui::regist *ui;
};

#endif // REGIST_H
