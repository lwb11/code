#include "client.h"
#include <QApplication>

#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>
#include <QVariantList>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    client w;
    w.show();

    return a.exec();
}
