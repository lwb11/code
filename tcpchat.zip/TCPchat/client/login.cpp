#include "login.h"
#include "ui_login.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>
#include <QVariantList>
#include "regist.h"

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);

    setWindowTitle("login");
    regist *reg = new regist;

    ui->lineName->setPlaceholderText("请输入用户名");
    ui->lineNum->setPlaceholderText("请输入密码");

    /*打印Qt支持的数据库驱动*/
    qDebug() << QSqlDatabase::drivers();

    /*添加Sqlite数据库*/
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    /*设置数据库*/
    db.setDatabaseName("../info.db");

    /*打开数据库*/
    if( !db.open() ) //数据库打开失败
    {
        QMessageBox::warning(this, "错误", db.lastError().text());
        return;
    }

    QSqlQuery query(db);
    QString cre = QString("create table users(username vchar primary key,pwd vchar)");
    query.exec(cre);

    query.exec("select * from users");

    while(query.next())
    {
        //取出当前行的内容
        qDebug() << query.value("username").toString()
                 << query.value("pwd").toInt();
    }

    connect(reg,&regist::back1,[=](){
        reg->close();
        this->show();
    });
    connect(ui->btnRegister,&QPushButton::clicked,[=](){
        this->hide();
        reg->show();
    });
}

login::~login()
{
    delete ui;
}

void login::on_btnFind_clicked()    //取消登录
{
    ui->lineName->clear();
    ui->lineNum->clear();
    emit this->back();
}

void login::on_btnLogin_clicked()     //登陆按钮
{
    QString user;
    QString pwd;
    user=ui->lineName->text();
    pwd=ui->lineNum->text();
    if(user==""){QMessageBox::warning(this,"","用户名不能为空！");}
    else if(pwd==""){QMessageBox::warning(this,"","密码不能为空！");}
    else{

        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection")){db=QSqlDatabase::database("qt_sql_default_connection");}
        else{
            db=QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("users.db");
        db.open();
        QSqlQuery query(db);
        QString s=QString("select *from users where username='%1' and pwd='%2'").arg(user).arg(pwd);
        query.exec(s);
        if(query.first()){
            QMessageBox::information(this,"","登录成功！");
            emit this->back();
        }
        else{
            QMessageBox::warning(this,"","用户名或密码错误！");
        }
        db.close();

    }
}

//void login::on_btnRegister_clicked()     //注册按钮
//{
//    QString user;
//    QString pwd;
//    user=ui->lineName->text();
//    pwd=ui->lineNum->text();
//    if(user==""){QMessageBox::warning(this,"","用户名不能为空！");}
//    else if(pwd==""){QMessageBox::warning(this,"","密码不能为空！");}
//    else{
//        QSqlDatabase db;
//        if(QSqlDatabase::contains("qt_sql_default_connection")){db=QSqlDatabase::database("qt_sql_default_connection");}
//        else{
//            db=QSqlDatabase::addDatabase("QSQLITE");
//        }
//        db.setDatabaseName("users.db");
//        db.open();

//        QString i=QString("insert into users values('%1','%2')").arg(user).arg(pwd);
//        QString s=QString("select*from users where username='%1'").arg(user);
//        QSqlQuery query(db);
//        if(query.exec(s)&&query.first()){
//           QMessageBox::warning(this,"","用户名重复！");
//        }
//        else if(query.exec(i)){
//            QMessageBox::information(this,"","注册成功！"
//                                             "请重新登陆");

//            query.exec("select * from users");

//            while(query.next())
//            {
//                //取出当前行的内容
//                qDebug() << query.value("username").toString()
//                         << query.value("pwd").toInt();
//            }
//        }

//     db.close();
//    }
//}

void login::on_btnDel_clicked()   //删除数据库数据
{
    QSqlDatabase db;
    if(QSqlDatabase::contains("qt_sql_default_connection")){db=QSqlDatabase::database("qt_sql_default_connection");}
    else{
        db=QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("users.db");
    db.open();
    QSqlQuery query(db);
//    QString sql=QString("update password set num = %1").arg(ui->lineNum->text());
//    if(!query.exec(sql))
//    {
//        qDebug()<<query.lastError();
//    }
//    else
//    {
//        qDebug()<<"update success!";
//    }
    QString del = QString("delete from users where pwd = %1").arg(ui->lineNum->text());
    query.exec(del);
    query.exec("select * from users");
    while(query.next())
    {
        //取出当前行的内容
        qDebug() << query.value("username").toString()
                 << query.value("pwd").toInt();
    }
    db.close();
}
