#ifndef CLIENT_H
#define CLIENT_H

#include <QMainWindow>
#include <QWidget>
#include <QTcpSocket>
#include <QFile>
#include <QTimer>
#include "login.h"

namespace Ui {
class client;
}

class client : public QMainWindow
{
    Q_OBJECT

public:
    explicit client(QWidget *parent = 0);
    ~client();

    QTcpSocket *clientSocket;

    QFile file; //文件对象
    QString fileName; //文件名字
    qint64 fileSize; //文件大小
    qint64 sendSize; //已经发送文件的大小
    qint64 recvSize; //已经接收文件的大小

    QTimer timer; //定时器

    bool isStart;   //标志位，是否为头部信息

    bool beFile;

//    login *in = NULL;

    void chooseFile();
    void sendFile();

private:
    Ui::client *ui;
};

#endif // CLIENT_H
