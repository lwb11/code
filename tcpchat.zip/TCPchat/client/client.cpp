#include "client.h"
#include "ui_client.h"

#include <QTcpSocket>
#include <QTcpServer>
#include <QMessageBox>
#include <QFileDialog>
#include <QTimer>
#include <QDateTime>

client::client(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::client)
{
    ui->setupUi(this);

    login *in = new login;

    setWindowTitle("client");

//    timer = new QTimer(this);

    beFile = false;
    isStart = true;

    clientSocket = new QTcpSocket(this);

    //点击连接按钮与服务器连接
    connect(ui->btnCon,&QPushButton::clicked,[=](){

        this->hide();
        in->show();
        connect(in,&login::back,[=](){   //登录成功后自动连接服务器

            this->show();
            in->close();

            clientSocket->connectToHost(QHostAddress(ui->serverIp->text()),ui->serverPort->text().toInt());

            //连接成功触发connented信号
            connect(clientSocket,&QTcpSocket::connected,[=](){
                QString str = QString("成功连接服务器");
                ui->textRead->setText(str);
            });
        });
    });

    //对端发送信息触发readyread信号进行读信息
    connect(clientSocket,&QTcpSocket::readyRead,[=](){
        QByteArray buf = clientSocket->readAll();
        QString strr = QString(buf).section("##",0,0);
        if(beFile == true || strr == "ok"){
            beFile = true;
            if(true == isStart)
            {
                isStart = false;
                fileName = QString(buf).section("##",1,1);
                fileSize = QString(buf).section("##",2,2).toInt();
                qDebug() << "名字：" << fileName << "大小：" << fileSize;
                recvSize = 0;

                file.setFileName(fileName);

                bool isOk = file.open(QIODevice::WriteOnly);
                if(isOk == false)
                {
                    qDebug()<<"只读方式打开出错";
                }
            }
            else
            {
                qint64 len = file.write(buf);
                if(len < 0){
                    qDebug()<<"写入文件失败";
                }
                recvSize +=len;
                qDebug()<<"接受文件长度："<<recvSize;
                qDebug()<<"实际文件长度："<<fileSize;
//                qDebug()<<"**************接收的信息**************:"<<buf;
                if(recvSize==fileSize)
                {
                    file.close();
                    QMessageBox::information(this,"完成","文件接收完成");
                    isStart = true;
                    beFile = false;
                }
            }
        }
        /*if(strr != "ok" && beFile == false)*/else{
            ui->textRead->append(buf);
        }

    });

    //点击发送按钮发送信息
    connect(ui->btnSend,&QPushButton::clicked,[=](){
        QString str = QDateTime::currentDateTime().toString("dddd.yyyy.MM.dd HH:mm:ss") + '\n';
        clientSocket->write(ui->textWrite->toPlainText().toUtf8().data());
        ui->textRead->append(str + "I say:" + ui->textWrite->toPlainText());
        ui->textWrite->clear();
    });

    connect(ui->btnFile,&QPushButton::clicked,[=](){
        chooseFile();

        sendFile();
    });

    //点击断开连接按钮，断开连接
    connect(ui->btnDis,&QPushButton::clicked,[=](){
        clientSocket->disconnectFromHost();
        clientSocket->close();
        ui->textRead->setText("与服务器断开连接.......");
    });
}

client::~client()
{
    delete ui;
}

void client::chooseFile()
{
    QString filePath = QFileDialog::getOpenFileName(this,"打开","/home/li/linux/qt_tool/qt/qt_licheng");
    if(filePath.isEmpty() == true)
    {
        qDebug()<<"打开文件出错";
    }
    fileName.clear();
    fileSize = 0;

    //获取文件信息
    QFileInfo info(filePath);
    fileName = info.fileName(); //获取文件名字
    fileSize = info.size(); //获取文件大小

    sendSize = 0; //发送文件的大小

    //只读方式打开文件
    //指定文件的名字
    file.setFileName(filePath);

    //打开文件
    bool isOk = file.open(QIODevice::ReadOnly);
    if(false == isOk)
    {
        qDebug() << "只读方式打开文件失败 106";
    }

    //提示打开文件的路径
    ui->textRead->append(filePath);
}

void client::sendFile()
{
    qDebug()<<"发送文件";
    //先发送文件头信息  文件名##文件大小
    QString isFile = "ok";
    QString head = QString("%1##%2##%3").arg(isFile).arg(fileName).arg(fileSize);
//                        QString head = QString("%1:%2").arg(fileName).arg(fileSize);
    //发送头部信息
    qint64 len = clientSocket->write( head.toUtf8() );
    if(len > 0)//头部信息发送成功
    {
        //发送真正的文件信息
        //防止TCP黏包
        //需要通过定时器延时 20 ms
        timer.start(20);
        connect(&timer, &QTimer::timeout,[=](){
            //关闭定时器
            timer.stop();

            //发送文件
            ui->textRead->append("正在发送文件……");
             qint64 len = 0;
             do
             {
                //每次发送数据的大小
                char buf[4*1024] = {0};
                len = 0;

                //往文件中读数据
                len = file.read(buf, sizeof(buf));
                //发送数据，读多少，发多少
                len = clientSocket->write(buf, len);
//                qDebug()<<"send:"<<buf;

                //发送的数据需要累积
                sendSize += len;
                qDebug()<<"发送文件长度："<<sendSize;
                qDebug()<<"实际文件长度："<<fileSize;

             }while(len > 0);

                  //是否发送文件完毕
                  if(sendSize == fileSize)
                  {
                      ui->textRead->append("文件发送完毕");
                      file.close();
                  }
        });
    }
    else
    {
        qDebug() << "头部信息发送失败 142";
        file.close();
    }
}
