#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include "client.h"
#include "regist.h"

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = 0);
    ~login();

//    client *clientScene = NULL;
//    regist *reg =NULL;

private slots:
    void on_btnFind_clicked();

    void on_btnLogin_clicked();

    void on_btnRegister_clicked();

    void on_btnDel_clicked();

signals:
    void back();

private:
    Ui::login *ui;
};

#endif // LOGIN_H
