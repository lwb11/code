#ifndef SERVER_H
#define SERVER_H

#include <QMainWindow>
#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QFile>
#include <QTimer>
namespace Ui {
class server;
}

class server : public QMainWindow
{
    Q_OBJECT

public:
    explicit server(QWidget *parent = 0);
    ~server();

    QTcpServer *tcpServer;
    QTcpSocket *tcpSocket;

    QFile file; //文件对象
    QString fileName; //文件名字
    qint64 fileSize; //文件大小
    qint64 sendSize; //已经发送文件的大小

    bool isStart;

    QTimer timer; //定时器

    QList <QTcpSocket*> clintList_sock;   //多个客户端的套接字列表

public slots:
    void readMessage();         //接收信息的槽函数
//    void myFunc();

private:
    Ui::server *ui;
};

#endif // SERVER_H
