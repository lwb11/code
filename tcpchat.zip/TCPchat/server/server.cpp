#include "server.h"
#include "ui_server.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QFileDialog>
#include <QDebug>
#include <QPushButton>
#include <QFile>
#include <QTimer>
#include <QDateTime>

server::server(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::server)
{
    ui->setupUi(this);

    ui->setupUi(this);

    //设置对话框标题
    setWindowTitle("server");
    tcpServer = new QTcpServer(this);

    //设置服务器的IP和端口号
    ui->ip->setText("127.0.0.1");
    ui->port->setText("9999");

    //监听端口
    tcpServer->listen(QHostAddress(ui->ip->text()),ui->port->text().toInt());

    connect(tcpServer,&QTcpServer::newConnection,[=](){

            //获得通信socket
            tcpSocket = tcpServer->nextPendingConnection();
            clintList_sock.push_back(tcpSocket);           //将连接的客户端放入客户端列表中
            //打印客户端的ip和端口号
            QString ip = tcpSocket->peerAddress().toString();
            quint16 port = tcpSocket->peerPort();
            QString str = QString("[%1:%2],成功连接").arg(ip).arg(port);
            ui->listWidget->addItem(str);
            QString s = QString("client");
            QString str1 = QString("%1:%2").arg(s).arg(port);
            ui->comboBox->addItem(str1);

//            for(int i = 0; i < clintList_sock.count(); i++){
//                QString s = QString("client");
//                quint16 port = clintList_sock.at(i)->peerPort();
//                QString str2 = QString("%1##%2").arg(s).arg(port);
//                clintList_sock.at(i)->write(str2.toUtf8());
//            }


            connect(tcpSocket,&QTcpSocket::readyRead,this,[=](){
                    readMessage();
            });


    });
}

server::~server()
{
    delete ui;
}

void server::readMessage()
{
    QTcpSocket*  currentClint;
    QByteArray arr;
//    QString str;
    if(!clintList_sock.isEmpty())      //有客户端存在
    {
        for(int i = 0; i < clintList_sock.count(); i++)     //服务端接收信息
        {
            arr = clintList_sock.at(i)->readAll();      //接收客户端发送的字节信息

//            qDebug()<<"就挺奇怪！！！！"<<arr;
            if(arr.isNull())  continue;   //空代表不是该客户端发送
            currentClint = clintList_sock.at(i);
//            quint16 clientport = currentClint->peerPort();
//            QString s = QString("%1").arg(clientport);
//            QString arr1 = arr;
//            qDebug()<<"能收到吧！！！！"<<arr1;
//            str = QDateTime::currentDateTime().toString("dddd.yyyy.MM.dd HH:mm:ss") + '\n' + "端口:" + s + "##" + arr1;
//            qDebug()<<str;
            break;
        }
        ui->textMessage->append(arr);     //显示信息

        for(int i = 0; i < clintList_sock.count(); i++)     //给其它客户端发送信息
        {
            QTcpSocket *temp = clintList_sock.at(i);
            if(currentClint == temp)  continue;      //遇到自己就跳过
            temp->write(arr);   //发送信息
        }
    }

}
