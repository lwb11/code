/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_login
{
public:
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *lineName;
    QLabel *label_2;
    QLineEdit *lineNum;
    QCheckBox *checkBox;
    QPushButton *btnDel;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *btnRegister;
    QPushButton *btnLogin;
    QPushButton *btnFind;

    void setupUi(QWidget *login)
    {
        if (login->objectName().isEmpty())
            login->setObjectName(QStringLiteral("login"));
        login->resize(356, 213);
        layoutWidget = new QWidget(login);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 30, 178, 64));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineName = new QLineEdit(layoutWidget);
        lineName->setObjectName(QStringLiteral("lineName"));

        gridLayout->addWidget(lineName, 0, 1, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        lineNum = new QLineEdit(layoutWidget);
        lineNum->setObjectName(QStringLiteral("lineNum"));
        lineNum->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(lineNum, 1, 1, 1, 1);

        checkBox = new QCheckBox(login);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setGeometry(QRect(190, 100, 81, 26));
        btnDel = new QPushButton(login);
        btnDel->setObjectName(QStringLiteral("btnDel"));
        btnDel->setGeometry(QRect(340, 200, 20, 20));
        widget = new QWidget(login);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(50, 140, 254, 30));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        btnRegister = new QPushButton(widget);
        btnRegister->setObjectName(QStringLiteral("btnRegister"));

        horizontalLayout->addWidget(btnRegister);

        btnLogin = new QPushButton(widget);
        btnLogin->setObjectName(QStringLiteral("btnLogin"));

        horizontalLayout->addWidget(btnLogin);

        btnFind = new QPushButton(widget);
        btnFind->setObjectName(QStringLiteral("btnFind"));

        horizontalLayout->addWidget(btnFind);


        retranslateUi(login);

        QMetaObject::connectSlotsByName(login);
    } // setupUi

    void retranslateUi(QWidget *login)
    {
        login->setWindowTitle(QApplication::translate("login", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("login", "\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        lineName->setText(QString());
        label_2->setText(QApplication::translate("login", "\345\257\206    \347\240\201", Q_NULLPTR));
        lineNum->setText(QString());
        checkBox->setText(QApplication::translate("login", "\350\256\260\344\275\217\345\257\206\347\240\201", Q_NULLPTR));
        btnDel->setText(QString());
        btnRegister->setText(QApplication::translate("login", "\346\263\250\345\206\214", Q_NULLPTR));
        btnLogin->setText(QApplication::translate("login", "\347\231\273\345\275\225", Q_NULLPTR));
        btnFind->setText(QApplication::translate("login", "\345\217\226\346\266\210", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class login: public Ui_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
