/********************************************************************************
** Form generated from reading UI file 'regist.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGIST_H
#define UI_REGIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_regist
{
public:
    QWidget *layoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *lineName;
    QSpacerItem *verticalSpacer;
    QLabel *label_2;
    QLineEdit *lineNum;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_3;
    QLineEdit *lineQuestion;
    QSpacerItem *verticalSpacer_3;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QPushButton *btnLogin;
    QPushButton *btnReg;
    QPushButton *btnQuit;

    void setupUi(QWidget *regist)
    {
        if (regist->objectName().isEmpty())
            regist->setObjectName(QStringLiteral("regist"));
        regist->resize(295, 276);
        layoutWidget = new QWidget(regist);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(50, 30, 193, 164));
        formLayout = new QFormLayout(layoutWidget);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lineName = new QLineEdit(layoutWidget);
        lineName->setObjectName(QStringLiteral("lineName"));

        formLayout->setWidget(0, QFormLayout::FieldRole, lineName);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(1, QFormLayout::FieldRole, verticalSpacer);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setLayoutDirection(Qt::LeftToRight);

        formLayout->setWidget(2, QFormLayout::LabelRole, label_2);

        lineNum = new QLineEdit(layoutWidget);
        lineNum->setObjectName(QStringLiteral("lineNum"));
        lineNum->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(2, QFormLayout::FieldRole, lineNum);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(3, QFormLayout::FieldRole, verticalSpacer_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_3);

        lineQuestion = new QLineEdit(layoutWidget);
        lineQuestion->setObjectName(QStringLiteral("lineQuestion"));
        lineQuestion->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(4, QFormLayout::FieldRole, lineQuestion);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(5, QFormLayout::FieldRole, verticalSpacer_3);

        layoutWidget1 = new QWidget(regist);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(20, 220, 254, 30));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        btnLogin = new QPushButton(layoutWidget1);
        btnLogin->setObjectName(QStringLiteral("btnLogin"));

        horizontalLayout->addWidget(btnLogin);

        btnReg = new QPushButton(layoutWidget1);
        btnReg->setObjectName(QStringLiteral("btnReg"));

        horizontalLayout->addWidget(btnReg);

        btnQuit = new QPushButton(layoutWidget1);
        btnQuit->setObjectName(QStringLiteral("btnQuit"));

        horizontalLayout->addWidget(btnQuit);


        retranslateUi(regist);

        QMetaObject::connectSlotsByName(regist);
    } // setupUi

    void retranslateUi(QWidget *regist)
    {
        regist->setWindowTitle(QApplication::translate("regist", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("regist", "\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        label_2->setText(QApplication::translate("regist", "\345\257\206\347\240\201", Q_NULLPTR));
        label_3->setText(QApplication::translate("regist", "\347\241\256\350\256\244\345\257\206\347\240\201", Q_NULLPTR));
        btnLogin->setText(QApplication::translate("regist", "\347\231\273\345\275\225", Q_NULLPTR));
        btnReg->setText(QApplication::translate("regist", "\346\263\250\345\206\214", Q_NULLPTR));
        btnQuit->setText(QApplication::translate("regist", "\345\217\226\346\266\210", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class regist: public Ui_regist {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGIST_H
