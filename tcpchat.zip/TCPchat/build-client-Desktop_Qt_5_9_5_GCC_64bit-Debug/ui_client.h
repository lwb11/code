/********************************************************************************
** Form generated from reading UI file 'client.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_client
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *serverIp;
    QLabel *label_2;
    QLineEdit *serverPort;
    QPushButton *btnCon;
    QPushButton *btnDis;
    QTextEdit *textRead;
    QTextEdit *textWrite;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *btnSend;
    QPushButton *btnFile;
    QComboBox *comboBox;
    QListWidget *listWidget;

    void setupUi(QMainWindow *client)
    {
        if (client->objectName().isEmpty())
            client->setObjectName(QStringLiteral("client"));
        client->resize(724, 358);
        centralWidget = new QWidget(client);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        serverIp = new QLineEdit(centralWidget);
        serverIp->setObjectName(QStringLiteral("serverIp"));

        horizontalLayout->addWidget(serverIp);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        serverPort = new QLineEdit(centralWidget);
        serverPort->setObjectName(QStringLiteral("serverPort"));

        horizontalLayout->addWidget(serverPort);

        btnCon = new QPushButton(centralWidget);
        btnCon->setObjectName(QStringLiteral("btnCon"));

        horizontalLayout->addWidget(btnCon);

        btnDis = new QPushButton(centralWidget);
        btnDis->setObjectName(QStringLiteral("btnDis"));

        horizontalLayout->addWidget(btnDis);


        gridLayout->addLayout(horizontalLayout, 0, 1, 1, 1);

        textRead = new QTextEdit(centralWidget);
        textRead->setObjectName(QStringLiteral("textRead"));
        textRead->setBaseSize(QSize(0, 0));

        gridLayout->addWidget(textRead, 1, 1, 1, 1);

        textWrite = new QTextEdit(centralWidget);
        textWrite->setObjectName(QStringLiteral("textWrite"));

        gridLayout->addWidget(textWrite, 2, 1, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        btnSend = new QPushButton(centralWidget);
        btnSend->setObjectName(QStringLiteral("btnSend"));

        horizontalLayout_2->addWidget(btnSend);

        btnFile = new QPushButton(centralWidget);
        btnFile->setObjectName(QStringLiteral("btnFile"));

        horizontalLayout_2->addWidget(btnFile);


        gridLayout->addLayout(horizontalLayout_2, 3, 1, 1, 1);

        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));

        gridLayout->addWidget(comboBox, 0, 0, 1, 1);

        listWidget = new QListWidget(centralWidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        gridLayout->addWidget(listWidget, 1, 0, 3, 1);

        client->setCentralWidget(centralWidget);

        retranslateUi(client);

        QMetaObject::connectSlotsByName(client);
    } // setupUi

    void retranslateUi(QMainWindow *client)
    {
        client->setWindowTitle(QApplication::translate("client", "client", Q_NULLPTR));
        label->setText(QApplication::translate("client", "IP", Q_NULLPTR));
        serverIp->setText(QApplication::translate("client", "127.0.0.1", Q_NULLPTR));
        label_2->setText(QApplication::translate("client", "Port", Q_NULLPTR));
        serverPort->setText(QApplication::translate("client", "9999", Q_NULLPTR));
        btnCon->setText(QApplication::translate("client", "\350\277\236\346\216\245", Q_NULLPTR));
        btnDis->setText(QApplication::translate("client", "\346\226\255\345\274\200", Q_NULLPTR));
        btnSend->setText(QApplication::translate("client", "\345\217\221\351\200\201", Q_NULLPTR));
        btnFile->setText(QApplication::translate("client", "\345\217\221\351\200\201\346\226\207\344\273\266", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class client: public Ui_client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
