#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H

#include <QPushButton>
#include <QMouseEvent>

class MyPushButton : public QPushButton
{
    Q_OBJECT
public:
    //explicit MyPushButton(QObject *parent = nullptr);
    //自定义控件  参数1：一个图片显示效果   参数2：两个图片组合显示效果
    MyPushButton(QString normalImg,QString pressImg = "");

    QString normalPath;  //起始图片路径
    QString pressPath;   //按下后图片路径

    //弹起效果函数，考虑写成一个函数
    void zoom1();  //向下跳
    void zoom2();  //向上跳

    //重写鼠标按下与释放事件
    void mousePressEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent *e);

signals:

public slots:
};

#endif // MYPUSHBUTTON_H



