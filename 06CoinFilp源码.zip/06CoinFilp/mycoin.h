#ifndef MYCOIN_H
#define MYCOIN_H

#include <QPushButton>
#include <QTimer>

class MyCoin : public QPushButton
{
    Q_OBJECT
public:
    //explicit MyCoin(QWidget *parent = nullptr);
    //重构函数
    MyCoin (QString m);
    //金币的属性
    int posX; //x坐标
    int posY; //y坐标
    bool flag;//正反标志  金币(true)为正
    //定义特效翻转最大最小值
    int min = 1;
    int max = 8;
    //定义定时器，全局利用
    QTimer *timer1;
    QTimer *timer2;

    //执行特效标志
    bool isAnimation  = false; //做翻转动画的标志。翻转时不可点击
    //是否胜利标志
    bool isWin = false; //是否胜利。注意playscene里面也有一个这个标志，两个标志各自作用是不同的，使用的先后顺序也不同
    //是否禁止点击标志
    bool isClick = false; //防止过快点击

    //重写按下事件
    void mousePressEvent(QMouseEvent *e);

    //翻转金币函数
    void changeCion();

signals:

public slots:
};

#endif // MYCOIN_H

