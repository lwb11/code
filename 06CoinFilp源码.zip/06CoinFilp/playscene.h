#ifndef PLAYSCENE_H
#define PLAYSCENE_H

#include <QMainWindow>
#include "mycoin.h"

class playScene : public QMainWindow
{
    Q_OBJECT
public:
//    explicit playScene(QWidget *parent = nullptr);
    //重写关卡函数，让关卡数传进去
    playScene(int levelNum);

    int num;
    //重写paintEvent事件函数 画背景图
    void paintEvent(QPaintEvent *); //参数没有名字，在重写函数中没使用参数才不会报错

    int gameArray[4][4]; //二维数组数据，维护每个关卡的具体数据。配合上面的关卡参数就可以得到具体哪一关的数据

    MyCoin * coinBtn[4][4]; //金币按钮数组，用于翻转周围的金币。指针数组

    bool isWin; //是否胜利。注意playscene里面也有一个这个标志，两个标志各自作用是不同的，使用的先后顺序也不同

    int grade(int n);//计算得分

signals:
    void mouseBackEvent1();//自定义信号用于返回主场景

public slots:
};

#endif // PLAYSCENE_H


