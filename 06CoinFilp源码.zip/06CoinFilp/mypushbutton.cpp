#include "mypushbutton.h"

#include <QPixmap>
#include <QDebug>
#include <QPropertyAnimation>

//MyPushButton::MyPushButton(QObject *parent) : QPushButton(parent)
//{

//}

MyPushButton::MyPushButton(QString normalImg,QString pressImg)
{
    //将输入函数的参数传入，保存
    this->normalPath = normalImg;

    this->pressPath = pressImg;
    //创建pix对象
    QPixmap pix;
    //判断传入的图片是否加载成功
    bool ret = pix.load(normalImg);

    if(ret == 0){
        qDebug()<<"图片加载失败";
        return;
    }
    //设置图片大小
    this->setFixedSize(pix.width(),pix.height());
    //设置不规则图片样式。使矩形变成不规则图形
    this->setStyleSheet("QPushButton{border:0px;}");
    //设置图标，不同于画图，这里是设置图标
    this->setIcon(pix);
    //设置图标大小，注意参数的类型是QSize
    this->setIconSize(QSize(pix.width(),pix.height()));

}

void MyPushButton::zoom1()
{
    //创建动画对象
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");
    //设置动画间隔时间
    animation->setDuration(220);
    //设置弹跳效果
    animation->setEasingCurve(QEasingCurve::OutBounce);
    //设置起始位置
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    //设置弹跳位置
    animation->setEndValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    //开始动画
    animation->start();
}

void MyPushButton::zoom2()
{
    //创建动画对象
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");
    //设置动画间隔时间
    animation->setDuration(220);
    //设置弹跳效果
    animation->setEasingCurve(QEasingCurve::OutBounce);
    //设置起始位置
    animation->setStartValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    //设置弹跳位置
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));
    //开始动画
    animation->start();
}

void MyPushButton::mousePressEvent(QMouseEvent *e)
{
    if(this->pressPath != "")
    {
        QPixmap pix;
        //判断传入的图片是否加载成功
        bool ret1 = pix.load(this->pressPath);

        if(ret1 == 0){
            qDebug()<<"图片加载失败";
            return;
        }
        //设置图片大小
        this->setFixedSize(pix.width(),pix.height());
        //设置不规则图片样式。使矩形变成不规则图形
        this->setStyleSheet("QPushButton{border:0px;}");
        //设置图标，不同于画图，这里是设置图标
        this->setIcon(pix);
        //设置图标大小，注意参数的类型是QSize
        this->setIconSize(QSize(pix.width(),pix.height()));

    }//要在执行完上述操作后,再return
    //让父类执行其他内容。比如触发Clicked信号,此处只做这个加载图片操作
    return QPushButton::mousePressEvent(e);
}

void MyPushButton::mouseReleaseEvent(QMouseEvent *e)
{
    if(this->pressPath != "")
    {
        QPixmap pix;
        //判断传入的图片是否加载成功
        bool ret1 = pix.load(this->normalPath);

        if(ret1 == 0){
            qDebug()<<"图片加载失败";
            return;
        }
        //设置图片大小
        this->setFixedSize(pix.width(),pix.height());
        //设置不规则图片样式。使矩形变成不规则图形
        this->setStyleSheet("QPushButton{border:0px;}");
        //设置图标，不同于画图，这里是设置图标
        this->setIcon(pix);
        //设置图标大小，注意参数的类型是QSize
        this->setIconSize(QSize(pix.width(),pix.height()));

    }//要在执行完上述操作后,再return
    //让父类执行其他内容。比如触发Clicked信号,此处只做这个加载图片操作
    return QPushButton::mouseReleaseEvent(e);
}
