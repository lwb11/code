#include "playscene.h"
#include <QMenuBar>
#include <QMenu>
#include "mypushbutton.h"
#include <QPainter>
#include <QDebug>
#include <QLabel>
#include "choosescene.h"
#include "dataconfig.h"
#include "mycoin.h"
#include <QPropertyAnimation>
#include <QSound>
#include <QMessageBox>
#include <QTimer>

playScene::playScene(int levelNum)
{
//    QString str = QString("进入了第 %1 关 ").arg(levelNum);
//    qDebug() << str;
//    this->num = levelNum; //传进来的关卡数给定义的全局变量
    //设置窗口大小
    this->setFixedSize(340,588);
    //设置窗口标题
    this->setWindowTitle("游戏场景");
    //设置窗口图标
    this->setWindowIcon(QPixmap(":/res/Coin0001.png"));

    //添加菜单栏
    QMenuBar *bar = new QMenuBar;
    /*bar->setParent(this);*/
    setMenuBar(bar);
    //创建开始菜单
    QMenu *startBar = bar->addMenu("选项");
    QMenu *aboutBar = bar->addMenu("关于");
    //添加菜单项
    QAction *quitBar = startBar->addAction("退出");
    QAction *ruleBar = aboutBar->addAction("规则");
    QAction *messageBar = aboutBar->addAction("相关信息");
    //退出按钮实现退出
    connect(quitBar,&QAction::triggered,[=](){
       this->close();
    });
    //设置关于菜单的实现
    connect(ruleBar,&QAction::triggered,[=](){
        QMessageBox::information(this,"规则","需要将所有币都翻成金币，即为胜利。");
    });
    connect(messageBar,&QAction::triggered,[=](){
        QMessageBox::information(this,"相关信息","版本号1.0.0,Made by Li");
    });

    //显示用时(秒)
    QLabel *lab0 = new QLabel;
    lab0->setParent(this);
    lab0->setGeometry(0,0,200,50);
    lab0->move(20,500);
    QFont font0;
    font0.setFamily("华文新魏");
    font0.setPointSize(14);
    //将字体应用到标签上
    lab0->setFont(font0);
    QTimer *timer0 = new QTimer(this);

    //计时器计时开始
    timer0->start(1000);
    static int num0 = 1;
    connect(timer0,&QTimer::timeout,[=](){
        //lab0 每隔1秒+1
        QString str0 = QString("闯关用时： %1 秒").arg(num0++);
        lab0->setText(str0);
        });

    //设置返回按钮
    MyPushButton *backBtn = new MyPushButton(":/res/BackButton.png",":/res/BackButtonSelected.png");
    //添加到父类
    backBtn->setParent(this);
    //移动位置
    backBtn->move(this->width()-backBtn->width()-10,this->height()-backBtn->height()-10);
    //设置返回按钮音效、胜利音效和翻金币音效
    QSound *backSound = new QSound(":/res/BackButtonSound.wav",this);
    QSound *winSound = new QSound(":/res/LevelWinSound.wav",this);
    QSound *flipSound = new QSound(":/res/ConFlipSound.wav",this);
    connect(backBtn,&MyPushButton::clicked,[=](){
       qDebug()<<"游戏场景返回按钮按下";
       //播放返回按钮音效
       backSound->play();
       emit this->mouseBackEvent1();
       timer0->stop();
       num0 = 1;
    });

    //显示关卡数
    this->num = levelNum; //传进来的关卡数给定义的全局变量
    QLabel *lab = new QLabel;
    lab->setParent(this);
    lab->setGeometry(30, this->height() - 50,130, 50);
    //设置显示的字体字号
    QFont font;
    font.setFamily("华文新魏");
    font.setPointSize(20);
    //将字体应用到标签上
    lab->setFont(font);
    QString str4 = QString("第 %1 关").arg(num);
    qDebug()<<str4;
    lab->setText(str4);

    //显示得分情况
    QLabel *gradeLab = new QLabel;
    gradeLab->setParent(this);
    gradeLab->setGeometry(0,0,130,50);
    //设置显示的字体字号
    QFont gradeFont;
    gradeFont.setFamily("华文新魏");
    gradeFont.setPointSize(20);
    //将字体应用到标签上
    gradeLab->setFont(gradeFont);
    gradeLab->move(105,405);

    //胜利图片的加载
    QLabel *winLab = new QLabel;
    QPixmap pix3;
    pix3.load(":/res/LevelCompletedDialogBg.png");
    winLab->setPixmap(pix3);
    winLab->setParent(this);
    winLab->setGeometry(0,0,winLab->width(),winLab->height());
    winLab->move((this->width() - winLab->width())*0.5+200 , -winLab->height());

    //从dataconfig里面取出对应关卡的起始数据
    /****************************************************/
    //初始化每个关卡的二维数组
    dataConfig config;
    for(int i = 0 ; i < 4;i++)
    {
         for(int j = 0 ; j < 4; j++)
         {
             //即把dataconfig里面每一关的数据给拆出来，放到gameArray[i][j]进行维护，维护金币状态
             this->gameArray[i][j] = config.mData[this->num][i][j]; //注意不是指针，所以用不了->
         }
    }

    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            //设置金币背景
            QLabel *lab1 = new QLabel;
            lab1->setGeometry(0,0,50,50);
            lab1->setPixmap(QPixmap(":/res/BoardNode.png"));
            lab1->setParent(this);
            lab1->move(70+i*50,200+j*50);

            //设置金币排列
            QString img;
            if(this->gameArray[i][j] == 1)
            {
                img = ":/res/Coin0001.png";
            }else{
                img = ":/res/Coin0008.png";
            }
            MyCoin *icon =  new MyCoin(img);
            icon->setParent(this);
            icon->move(72+i*50,202+j*50);


            //给金币属性赋值，用于确定是哪一个金币以及状态。便于翻转金币
            icon->posX = i;
            icon->posY = j;
            icon->flag = this->gameArray[i][j]; //1正面 0反面。注意左边的类型是bool，右边的是int会被强制转换为左边bool的类型
            //将金币放入到 金币的二维数组里 以便后期维护。注意数组的类型，不是int
            coinBtn[i][j] = icon;

            //设置金币翻转
            connect(icon,&MyCoin::clicked,[=](){
                QString str8 = QString("金币icon坐标x:%1,y:%2").arg(coinBtn[i][j]->posX).arg(coinBtn[i][j]->posY);
                qDebug()<<str8;//"点击了金币";
                QString str9 = QString("金币gameArray坐标x:%1,y:%2").arg(i).arg(j);
                qDebug()<<str9;//"点击了金币";
                //翻金币音效
                flipSound->play();
                icon->changeCion();
                this->gameArray[i][j] = this->gameArray[i][j] == 0 ? 1 : 0;

                //设置周围金币翻转
                QTimer::singleShot(300, this,[=](){
                    //翻转右侧的硬币
                    if(icon->posX+1 <=3)
                    {
                      coinBtn[icon->posX+1][icon->posY]->changeCion();
                      this->gameArray[icon->posX+1][icon->posY] = this->gameArray[icon->posX+1][icon->posY]== 0 ? 1 : 0;
                    }
                    //翻转左侧的硬币
                    if(icon->posX-1>=0)
                    {
                      coinBtn[icon->posX-1][icon->posY]->changeCion();
                      this->gameArray[icon->posX-1][icon->posY] = this->gameArray[icon->posX-1][icon->posY]== 0 ? 1 : 0;
                    }
                    //翻转下侧的硬币
                    if(icon->posY+1<=3)
                    {
                     coinBtn[icon->posX][icon->posY+1]->changeCion();
                     this->gameArray[icon->posX][icon->posY+1] = this->gameArray[icon->posX][icon->posY+1]== 0 ? 1 : 0;
                    }
                    //翻转上侧的硬币
                    if(icon->posY-1>=0)
                    {
                     coinBtn[icon->posX][icon->posY-1]->changeCion();
                     this->gameArray[icon->posX][icon->posY-1] = this->gameArray[icon->posX][icon->posY-1]== 0 ? 1 : 0;
                    }
                    //判断是否胜利
                    //一定注意判断胜利是在翻动上下左右硬币代码之后，而且要在延时里面（如果有延时，一定要在延时里面！！！因为执行顺序会被打乱，会导致判断胜利在前，翻转在后）
                    //判断是否胜利。注意是整体判断，所以不放在MyCoin里面
                    this->isWin = true;
                    for(int i = 0 ; i < 4;i++)
                    {
                         for(int j = 0 ; j < 4; j++)
                         {
    //                         QString str6 = QString("金币:%1").arg(coinBtn[i][j]->flag);
    //                         qDebug()<<str6;
                             if(coinBtn[i][j]->flag == false)
                             {
                                 this->isWin = false;
                             }
                         }
                    }
                    if(this->isWin == true)
                    {
                        qDebug()<<"胜利";
                        //胜利后禁用按钮
                        for(int i = 0 ; i < 4;i++)
                        {
                             for(int j = 0 ; j < 4; j++)
                             {
                                 coinBtn[i][j]->isWin = true;
                             }
                        }
                        QPropertyAnimation * animation = new QPropertyAnimation(winLab,"geometry");
                        //设置动画间隔时间
                        animation->setDuration(1000);
                        //设置弹跳效果
                        animation->setEasingCurve(QEasingCurve::OutBounce);
                        //设置起始位置
                        animation->setStartValue(QRect(winLab->x(),winLab->y(),winLab->width(),winLab->height()));
                        //设置弹跳位置
                        animation->setEndValue(QRect(winLab->x(),winLab->y()+350,winLab->width(),winLab->height()));
                        //开始动画
                        animation->start();
                        //胜利音效
                        winSound->play();
                        //胜利后关闭计时
                        timer0->stop();
                        //显示得分
                        int grade0 = grade(num0);
                        QString str7 = QString("得分：%1").arg(grade0);
                        qDebug()<<str7;
                        gradeLab->setText(str7);
                        num0 = 1;
                    }else{
                        qDebug()<<"失败";
                    }
//                 });
               });

           });
        }
    }
}

void playScene::paintEvent(QPaintEvent *)
{
    //创建画家
    QPainter painter(this);
    //创建QPixMap对象
    QPixmap pix;
    //加载图片
    pix.load(":/res/back.png");
    //绘制背景图。前两个参数是位置，之后两个参数是宽长（没有的话会自动空出状态栏），最后一个参数是图片路径
    painter.drawPixmap(0,0,this->width(),this->height(),pix);
    //加载标题
    pix.load(":/res/Title.png");
    //缩放图片
//    pix = pix.scaled( pix.width() * 0.5 , pix.height() * 0.5);
    //绘制标题。下面代码和上面的不同是少了第三四个参数，上面一行的作用是缩放
    painter.drawPixmap(this->width() * 0.5-pix.width() * 0.5,30,pix);
}

int playScene::grade(int n)
{
    int m = 100;
    if(n <= 10)
    {
        m = 100;
        return m;
    }else if(10 < n <=90){
        for(int a=n;a>10;a--){
            m = m-1;
        }
        return m;
    }else if(n > 90){
        m = 9;
        return m;
    }
}

