#include "choosescene.h"
#include <QMenuBar>
#include <QMenu>
#include <QPainter>
#include "mypushbutton.h"
#include <QDebug>
#include <QLabel>
#include "playscene.h"
#include <QTimer>
#include <QSound>
#include <QMessageBox>

ChooseScene::ChooseScene(QWidget *parent) : QMainWindow(parent)
{
    //设置窗口大小
    this->setFixedSize(340,588);
    //设置窗口标题
    this->setWindowTitle("选择关卡场景");
    //设置窗口图标
    this->setWindowIcon(QPixmap(":/res/Coin0001.png"));
    //添加菜单栏
    QMenuBar *bar = new QMenuBar;
//    bar->setParent(this);
    setMenuBar(bar);
    //创建开始菜单
    QMenu *startBar = bar->addMenu("选项");
    QMenu *aboutBar = bar->addMenu("关于");
    //添加菜单项
    QAction *quitBar = startBar->addAction("退出");
    QAction *ruleBar = aboutBar->addAction("规则");
    QAction *messageBar = aboutBar->addAction("相关信息");

    //退出按钮实现退出
    connect(quitBar,&QAction::triggered,[=](){
       this->close();
    });
    //设置关于菜单的实现
    connect(ruleBar,&QAction::triggered,[=](){
        QMessageBox::information(this,"规则","需要将所有币都翻成金币，即为胜利。");
    });
    connect(messageBar,&QAction::triggered,[=](){
        QMessageBox::information(this,"相关信息","版本号1.0.0,Made by Li");
    });
    //设置返回按钮
    MyPushButton *backBtn = new MyPushButton(":/res/BackButton.png",":/res/BackButtonSelected.png");
    //添加到父类
    backBtn->setParent(this);
    //移动位置
    backBtn->move(this->width()-backBtn->width()-10,this->height()-backBtn->height()-10);
    //设置返回按钮音效和选关按钮音效
    QSound *backSound = new QSound(":/res/BackButtonSound.wav",this);
    QSound *chooseSound = new QSound(":/res/TapButtonSound.wav",this);
    connect(backBtn,&MyPushButton::clicked,[=](){
//       qDebug()<<"返回按钮按下";
       //播放返回按钮音效
       backSound->play();
       emit this->mouseBackEvent();
    });
    //添加选关按钮
    for(int i=0;i<20;i++)
    {
        MyPushButton *btn1 =  new MyPushButton(":/res/LevelIcon.png");
        btn1->setParent(this);
        //设置图标位置
        btn1->move(40+i%4 * 70, 150+i/4 * 77);
        //设置按钮标签
        QLabel *lab = new QLabel;
        lab->setParent(this);
        lab->setFixedSize(btn1->width(),btn1->height());
        lab->setText(QString::number(i+1));//这个可以自动加一
//        lab->setText("i+1");//这个设置出来就是所有都为i+1
        lab->move(40+i%4 * 70, 150+i/4 * 77);
        //将文本放置在中间
        lab->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
        //鼠标透过标签可以按到按钮
        lab->setAttribute(Qt::WA_TransparentForMouseEvents);
//}
        //定义一个字符串显示按的按钮
//        QString str = QString("选了第 %1 关").arg(i+1);
        connect(btn1,&MyPushButton::clicked,[=](){
           QString str = QString("选了第 %1 关").arg(i+1);
           qDebug()<<str;
           //播放选关按钮音效
           chooseSound->play();
           //将选择的关卡数传给游戏场景
           play = new playScene(i+1);
           btn1->zoom1();
           btn1->zoom2();
           QTimer::singleShot(300,this,[=](){
               //设置游戏场景位置，使所有都保持在一个位置
               play->setGeometry(this->geometry());
               this->hide();
               play->show();

               });

           //监听返回按钮按下信号,一但收到则返回选关场景
           connect(play,&playScene::mouseBackEvent1,[=](){
               QTimer::singleShot(400,this,[=](){
                   //设置游戏场景位置，使所有都保持在一个位置
                   this->setGeometry(play->geometry());
                   //因为关卡数量多且每个关卡都不一样，所以每次关闭后都进行删除
                   delete play;
                   play = NULL;
                   this->show();
               });
           });
        });

    }


}

void ChooseScene::paintEvent(QPaintEvent *)
{
    //创建画家
    QPainter painter(this);
    //创建QPixMap对象
    QPixmap pix;
    //加载图片
    pix.load(":/res/back.png");
    //绘制背景图。前两个参数是位置，之后两个参数是宽长（没有的话会自动空出状态栏），最后一个参数是图片路径
    painter.drawPixmap(0,0,this->width(),this->height(),pix);
    //加载标题
    pix.load(":/res/Title.png");
    //缩放图片
//    pix = pix.scaled( pix.width() * 0.5 , pix.height() * 0.5);
    //绘制标题。下面代码和上面的不同是少了第三四个参数，上面一行的作用是缩放
    painter.drawPixmap(this->width() * 0.5-pix.width() * 0.5,30,pix);
}



