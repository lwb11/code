#ifndef CHOOSESCENE_H
#define CHOOSESCENE_H

#include <QMainWindow>
#include "playscene.h"

class ChooseScene : public QMainWindow
{
    Q_OBJECT
public:
    explicit ChooseScene(QWidget *parent = nullptr);

    //重写paintEvent事件函数 画背景图
    void paintEvent(QPaintEvent *); //参数没有名字，在重写函数中没使用参数才不会报错
    int i;
    playScene *play = NULL;

signals:
    void mouseBackEvent();//自定义信号用于返回主场景

public slots:
};

#endif // CHOOSESCENE_H


