#ifndef MAINSCENE_H
#define MAINSCENE_H

#include <QMainWindow>
#include "choosescene.h"

namespace Ui {
class MainScene;
}

class MainScene : public QMainWindow
{
    Q_OBJECT


public:   /*普通函数声明写在public下*
           *自定义槽放置在public slots下*
           *自定义信号放置在signals下 */
    explicit MainScene(QWidget *parent = 0);
    ~MainScene();

    //重写paintEvent事件函数 画背景图
    void paintEvent(QPaintEvent *); //参数没有名字，在重写函数中没使用参数才不会报错

    ChooseScene *choose = NULL; //设置全局效果

private:
    Ui::MainScene *ui;
};

#endif // MAINSCENE_H

