#include "mainscene.h"
#include "ui_mainscene.h"

#include <QPushButton>
#include <QPainter>
#include "mypushbutton.h"
#include <QDebug>
#include "choosescene.h"
#include <QTimer>
#include <QSound>   //多媒体模块下的音效头文件
#include <QMessageBox>

MainScene::MainScene(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainScene)
{
    ui->setupUi(this);

    //设置场景大小
    this->setFixedSize(340,588);
    //设置窗口标题
    this->setWindowTitle("游戏主场景");
    //设置标题图标
    this->setWindowIcon(QIcon(":/res/Coin0001.png"));
    //退出按钮实现。点击clicked是用在按钮上的，下面是触发triggered
    connect(ui->actionquit,&QAction::triggered,[=](){
       this->close();
    });
    //菜单栏关于的实现
    connect(ui->actionrule,&QAction::triggered,[=](){
        QMessageBox::information(this,"规则","需要将所有币都翻成金币，即为胜利。");
    });
    connect(ui->actionmessage,&QAction::triggered,[=](){
        QMessageBox::information(this,"相关信息","版本号1.0.0,Made by Li");
    });

    //准备开始按钮的音效
    QSound *startSound = new QSound(":/res/TapButtonSound.wav",this);
    QSound *backSound = new QSound(":/res/two.wav",this);
    backSound->play();
    backSound->setLoops(-1); //循环次数设置，-1为无限次

    //开始按钮的设置
    MyPushButton *btn =  new MyPushButton(":/res/MenuSceneStartButton.png");
    btn->setParent(this);
    //设置图标位置
    btn->move(this->width()*0.5 - btn->width()*0.5,350);

    //将按钮实例化，进行定义
    choose = new ChooseScene;
    //开始按钮信号，菜单栏信号连接到下边开始按钮
    connect(ui->actionstart,&QAction::triggered,btn,&MyPushButton::clicked);
    connect(btn,&MyPushButton::clicked,[=](){
//       qDebug()<<"按钮按下了";
       //播放开始音效
       startSound->play();
       backSound->stop();
       //弹跳效果调用
       btn->zoom1();
       btn->zoom2();
       //隐藏太快，看不到弹跳效果，加个延时
       QTimer::singleShot(400,this,[=](){
           //使所有窗口都保持在一起
           choose->setGeometry(this->geometry());  //注意先show后移动的话，会有闪动
           this->hide();
           choose->show();
       });

    });
    //监听返回按钮按下信号,一但收到则返回主场景
    connect(choose,&ChooseScene::mouseBackEvent,[=](){
        QTimer::singleShot(300,this,[=](){
            //使所有窗口都保持在一起
            this->setGeometry(choose->geometry());
            choose->hide();
            this->show();
        });
//        qDebug()<<"场景返回了";
    });



}
/*********这个函数的调用不清楚时什么时候进行的*******/
void MainScene::paintEvent(QPaintEvent *)
{
    //创建画家
    QPainter painter(this);
    //创建QPixMap对象
    QPixmap pix;
    //加载图片
    pix.load(":/res/MenuSceneBg.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);

    /************下面加载的背景图，需要手动添加图片标题************/

//    pix.load(":/res/PlayLevelSceneBg.png");
//    //绘制背景图。前两个参数是位置，之后两个参数是宽长（没有的话会自动空出状态栏），最后一个参数是图片路径
//    painter.drawPixmap(0,0,this->width(),this->height(),pix);

//    //加载标题
//    pix.load(":/res/Title.png");
//    //缩放图片
//    pix = pix.scaled( pix.width() * 0.5 , pix.height() * 0.5);
//    //绘制标题。下面代码和上面的不同是少了第三四个参数，上面一行的作用是缩放
//    painter.drawPixmap(this->width() * 0.5-pix.width() * 0.5,30,pix); //使其居中

}


MainScene::~MainScene()
{
    delete ui;
}

