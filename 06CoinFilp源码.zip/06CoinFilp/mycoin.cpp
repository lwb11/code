#include "mycoin.h"
#include <QDebug>
#include <QPainter>
#include <QPropertyAnimation>
#include <QTimer>
#include <QPushButton>

//MyCoin::MyCoin(QWidget *parent) : QPushButton(parent)
//{

//}

MyCoin::MyCoin (QString m)
{
    //创建pix对象
    QPixmap pix;
    //判断传入的图片是否加载成功
    bool ret = pix.load(m);

    if(ret == 0){
        qDebug()<<"图片加载失败";
        return;
    }
    //设置图片大小
    this->setFixedSize( pix.width(), pix.height() );
    //设置不规则图片样式。使矩形变成不规则图形
    this->setStyleSheet("QPushButton{border:0px;}");
    //设置图标，不同于画图，这里是设置图标
    this->setIcon(pix);
    //设置图标大小，注意参数的类型是QSize
    this->setIconSize(QSize(pix.width(),pix.height()));

    timer1 = new QTimer(this);//用于正翻时
    timer2 = new QTimer(this);//用于反翻时
    //金币正面翻转到反面
    connect(timer1,&QTimer::timeout,[=](){
        QPixmap pixmap;
        QString str = QString(":/res/Coin000%1.png").arg(this->min++);
        pixmap.load(str);
        this->setFixedSize(pixmap.width(),pixmap.height());
        this->setStyleSheet("QPushButton{border:0px;}");
        this->setIcon(pixmap);
        this->setIconSize(QSize(pixmap.width(),pixmap.height()));
        //翻转完毕就停止定时器，并且重置min
        if(this->min > this->max) //如果大于最大值，重置最小值，并停止定时器
        {
            this->min = 1;
            this->isAnimation  = false; //特效已经停止
            timer1->stop();
        }
    });
    //金币反面翻转到正面
    connect(timer2,&QTimer::timeout,[=](){
        QPixmap pixmap;
        QString str = QString(":/res/Coin000%1.png").arg(this->max--);
        pixmap.load(str);
        this->setFixedSize(pixmap.width(),pixmap.height());
        this->setStyleSheet("QPushButton{border:0px;}");
        this->setIcon(pixmap);
        this->setIconSize(QSize(pixmap.width(),pixmap.height()));
        //翻转完毕就停止定时器，并且重置min
        if(this->max < this->min) //如果大于最大值，重置最小值，并停止定时器
        {
            this->max = 8;
            this->isAnimation  = false; //特效已经停止
            timer2->stop();
        }
    });
}

void MyCoin::changeCion()
{
    if(this->flag == true)
    {
        this->flag = false;
        this->isAnimation = true;
        timer1->start(30);
    }else{
        this->flag = true;
        this->isAnimation = true;
        timer2->start(30);
    }
}

void MyCoin::mousePressEvent(QMouseEvent *e)
{
    if(this->isAnimation || this->isWin)
    {
        return;
    }else
        return QPushButton::mousePressEvent(e);
}
