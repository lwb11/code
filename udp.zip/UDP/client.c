#include "dabao.h"

#define SERVER_PORT 6666
#define MAXSIZE 100

int main(int argc,char *argv[])
{
	int sockfd,rn;
	char buf[MAXSIZE];
//	char str[100];

	struct sockaddr_in serveraddr;

	bzero(&serveraddr,sizeof(serveraddr));   //将地址结构清零
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET,"127.0.0.1",&serveraddr.sin_addr);

	sockfd = Socket(AF_INET,SOCK_DGRAM,0);   //UDP协议注意修改为SOCK_DGRAM

 	   while(fgets(buf,MAXSIZE,stdin) != NULL)
	{
	//	scanf("%s\n",buf);
		rn = sendto(sockfd,buf,strlen(buf),0,(struct sockaddr *)&serveraddr,sizeof(serveraddr));
		if (rn == -1){
			perr_exit("sendto error");
		}
		
		printf("发送的内容:%s",buf);
		rn = recvfrom(sockfd,buf,sizeof(buf),0,NULL,0);
		if (rn == -1){
			perr_exit("recvform error");
		}
		Write(STDOUT_FILENO,buf,rn);         //回写到电脑屏幕上     
	}
	Close(sockfd);

	return 0;
}
