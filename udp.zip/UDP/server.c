/*仅支持单客户端的服务器*/

#include "dabao.h"

#define SERVER_PORT 6666

int main(int argc,char *argv[])
{
	int sockfd,i,rn;
	struct sockaddr_in serveraddr,clientaddr;
	socklen_t client_addr_len;
	char buf[BUFSIZ],client_IP[1024];

	bzero(&serveraddr,sizeof(serveraddr));   //将地址结构清零
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERVER_PORT);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	//inet_pton(AF_INET,"192.168.1.457",&serveraddr.sin_addr);

	sockfd = Socket(AF_INET,SOCK_DGRAM,0);  //UDP注意协议的修改SOCK_DGRAM
	
	Bind(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));
	
//	client_addr_len = sizeof(clientaddr);

	while(1)
	{

		client_addr_len = sizeof(clientaddr);

		rn = recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr *)&clientaddr,&client_addr_len);
		printf("client ip:%s,client port:%d\n",
	inet_ntop(AF_INET,&clientaddr.sin_addr.s_addr,client_IP,sizeof(client_IP)),ntohs(clientaddr.sin_port));

		if (rn == -1){
			perr_exit("recvfrom error");
		}
		if (rn == 0){
			printf("the client has been closed.\n");
			break;
		}

		printf("%s\n",buf);
	//	Write(STDOUT_FILENO,buf,rn);      //回写到电脑屏幕上 

		for (i=0;i<rn;i++)
		{
			buf[i] = toupper(buf[i]);
		}
		rn = sendto(sockfd,buf,rn,0,(struct sockaddr *)&clientaddr,sizeof(clientaddr));
		if (rn == -1){
			perr_exit("sendto error");
		} 
	}
	Close(sockfd);

	return 0;
}
