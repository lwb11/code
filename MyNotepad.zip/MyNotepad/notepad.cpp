#include "notepad.h"
#include "ui_notepad.h"
#include <QMessageBox>
#include <QDebug>
#include <QFileInfo>
#include <QFileDialog>

notepad::notepad(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::notepad)
{
    ui->setupUi(this);

    /****************文件菜单实现***************/
    //new新建
    ui->actionnew->setShortcut(tr("CTRL+N"));
    connect(ui->actionnew,&QAction::triggered,[=](){
        if(maybeSave()){
            ui->textEdit->clear();
        }
    });

    //save保存
    ui->actionsave->setShortcut(tr("CTRL+S"));
    connect(ui->actionsave,&QAction::triggered,[=](){
//        QString str = QString("saved");
//        qDebug()<<str;
        on_save();
    });
    //saveAs另存为
    connect(ui->actionsaveAs,&QAction::triggered,[=](){
        on_saveAs();
    });

    //open打开
    ui->actionopen->setShortcut(tr("CTRL+O"));
    connect(ui->actionopen,&QAction::triggered,[=](){
        QString fileName = QFileDialog::getOpenFileName(this,"打开", "/home/li/linux/qt_tool/qt/qt_licheng/build-MyNotepad-Desktop_Qt_5_9_5_GCC_64bit-Debug/file");
        if(!fileName.isEmpty()){
//            QFileInfo fileinfo = QFileInfo(fileName);
//            QString file_name = fileinfo.fileName();//获取保存的文件的文件名
//            qDebug()<< "文件名:" << file_name.toUtf8().data();
            loadFile(fileName);
        }else{
            QMessageBox::warning(this, tr("Path"),tr("You did not select any file."));
        }
    });
    //quit退出
    connect(ui->actionquit,&QAction::triggered,[=](){
        if(ui->textEdit->document()->isEmpty()){
            this->close();
        }else{
            if(maybeSave()){
                this->close();
            }else{
                this->close();//不保存直接退出
            }
        }
    });
    /****************编辑菜单实现***************/
    //undo撤销
    ui->actionundo->setShortcut(tr("CTRL+Z"));
    connect(ui->actionundo,&QAction::triggered,[=](){
        ui->textEdit->undo();
    });
    //copy复制
    ui->actioncopy->setShortcut(tr("CTRL+C"));
    connect(ui->actioncopy,&QAction::triggered,[=](){
        ui->textEdit->copy();
    });
    //paste粘贴
    ui->actionpaste->setShortcut(tr("CTRL+C"));
    connect(ui->actionpaste,&QAction::triggered,[=](){
        ui->textEdit->paste();
    });
    //cut剪切
    ui->actioncut->setShortcut(tr("CTRL+X"));
    connect(ui->actioncut,&QAction::triggered,[=](){
        ui->textEdit->cut();
    });
    /****************帮助菜单实现***************/
    //关于记事本
    connect(ui->actionmessage,&QAction::triggered,[=](){
        QMessageBox::information(this,"版本信息","试验版1.0.0");
    });
}
//另存函数
void notepad::on_saveAs()
{
        QString fileName = QFileDialog::getSaveFileName(this,"保存","/home/li/linux/qt_tool/qt/qt_licheng/build-MyNotepad-Desktop_Qt_5_9_5_GCC_64bit-Debug/file");
//        QFileInfo fileinfo = QFileInfo(fileName);
//        QString file_name = fileinfo.fileName();//获取保存的文件的文件名
//        qDebug()<<file_name;    //打印文件名
        if(fileName != NULL){
            QFile file(fileName);
            if (!file.open(QIODevice::ReadWrite | QIODevice::Text))
            {
                QMessageBox::warning(this, tr("Write File"),tr("Cannot open file:\n%1").arg(fileName));
                return;
            }
                QTextStream out(&file);
                out << ui->textEdit->toPlainText();
//                qDebug()<<ui->textEdit->toPlainText();
                file.close();
                ui->textEdit->clear();
                QMessageBox::information(this,"提示","文件已保存！");
        }else{
                QMessageBox::warning(this, tr("提示"),
                tr("没有进行保存操作，文件未保存！"));
        }
}
//保存文件子函数
void notepad::saveFile(QString fileName)
{
    QFile file(fileName);
    if(!file.open(QFile::WriteOnly | QFile::Text))
    {
        QMessageBox::critical(this,"critical","cannot write file");
        return;
    }
    else
    {
        QTextStream out(&file);
        out<<ui->textEdit->toPlainText();
    }
}
//加载文件函数
void notepad::loadFile(QString fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::ReadWrite | QIODevice::Text )){
        QMessageBox::warning(this, tr("File"),tr("Cannot open file:\n%1").arg(fileName));
        return;
    }
    QTextStream in(&file);
    ui->textEdit->setText(in.readAll());
    setFile(fileName);
    file.close();
}
//传递出文件名函数
void notepad::setFile(QString fileName)
{
    currentFile = fileName;
}
//保存操作函数
void notepad::on_save()
{
    if(currentFile.isEmpty())
    {
        on_saveAs();
    }
    else
    {
        saveFile(currentFile);
    }
}

//判断文件是否被修改函数
bool notepad::maybeSave()
{
    if(ui->textEdit->document()->isModified())
    {
        QMessageBox::StandardButtons result;
        result = QMessageBox::warning(this,"记事本","是否保存文件?",
                    QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);

        if(result == QMessageBox::Cancel)
        {//取消
            return false;
        }
        if(result == QMessageBox::Save)
        {//保存
            on_save();
            return true;
        }
        if(result == QMessageBox::Discard)
        {//忽略，即不保存
            return true;
        }
    }
    else
    {
        return true;
    }
}


notepad::~notepad()
{
    delete ui;
}
