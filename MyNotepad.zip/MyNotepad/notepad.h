#ifndef NOTEPAD_H
#define NOTEPAD_H

#include <QMainWindow>
#include <QFile>

namespace Ui {
class notepad;
}

class notepad : public QMainWindow
{
    Q_OBJECT

public:
    explicit notepad(QWidget *parent = 0);
    ~notepad();

    QString currentFile;
//    QString file_name;
//    QFile file;

    void on_save();
    void on_saveAs();
    void saveFile(QString fileName);
    void loadFile(QString fileName);
    void setFile(QString fileName);
    bool maybeSave();
//    bool saveFile(QString fileName);

signals:

//    void isChange;

private:
    Ui::notepad *ui;
};

#endif // NOTEPAD_H
