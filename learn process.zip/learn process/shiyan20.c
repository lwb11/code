/*将a中的字符复制到b中*/

#include <stdio.h>

void main ()

{
	char a[] = "I love you!",b[30],*p;
	int i,j;
	p = &a[0];
	for (i=0;*(p+i) != '\0';i++)
	{
		b[i] = *(p+i);
	}
	b[i] = '\0';  //关键的一步，复制时不会把'\0'复制过去，所以要自己加上
	for (j=0;b[j] != '\0';j++)
	{
		printf("%c",b[j]);
	}
	printf("\n\n");
}
