
/*任意输入x,y，计算出x的y次方*/

#include <stdio.h>

void main ()

{
	int a,b,c;
	printf("input two number:   ");
	scanf("%d,%d",&a,&b);
	int power(int x,int y);
	c = power(a,b);
	printf("%d\n",c);
}

int power (int x,int y)

{
	int z=1,i;
	for (i=1;i<=y;i++)
	{
		z = z * x;
	}
	return z;
}

