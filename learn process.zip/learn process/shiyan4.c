/*输出:######
 *     #####
 *     ####
 *     ###
 *     ##
 *     #      */

#include <stdio.h>

void main()

{
	int i,j;
	for (i=1;i<7;i++)
  	{
		printf("\n");
		for (j=6;j>=i;j--)
		{
			putchar('#');
		}
	}
}
