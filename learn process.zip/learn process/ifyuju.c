#include <stdio.h>

void main()

{
//	int a,b;
//	printf("input two num\n");
//	scanf("%d %d",&a,&b);
//	if (a>b)
//	{
//		printf("max=%d\n",a);
//	}
//	else
//	{
//		printf("max=%d\n",b);
//	}

	int a;
	printf("input a score\n");
	scanf("%d",&a);
	if (a<60)
	{
		printf("E\n");
	}
	else if (60<=a && a<70)
	{	
		printf("D\n");
	}
	else if (70<=a && a<80)
	{
		printf("C\n");
	}
	else if (80<=a && a<90)
	{
		printf("B\n");
	}
	else if (90<=a)
	{
		printf("A\n");
	}
}
