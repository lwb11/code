#include <gtk/gtk.h>

void toggle (GtkWidget *widget,gpointer data)   //回调函数，切换进度条方向
{
	switch (gtk_progress_bar_get_orientation(GTK_PROGRESS_BAR(data)))
	{
		case GTK_PROGRESS_LEFT_TO_RIGHT:gtk_progress_bar_set_orientation(GTK_PROGRESS_BAR(data),GTK_PROGRESS_RIGHT_TO_LEFT);
			break;
		case GTK_PROGRESS_RIGHT_TO_LEFT:gtk_progress_bar_set_orientation(GTK_PROGRESS_BAR(data),GTK_PROGRESS_LEFT_TO_RIGHT);
			break;
		default:
			break;
	}
}

void callback (GtkWidget *widget,gpointer data)
{
	gdouble new_val = gtk_progress_bar_get_fraction(GTK_PROGRESS_BAR(data))+0.05;
	
	if (new_val > 1.0)
	{
		new_val = 0;
	}

	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(data),new_val);
}

int main (int argc,char *argv[])
{
	gtk_init(&argc,&argv);
	
	GtkWidget *w;
	w = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	gtk_window_set_title(GTK_WINDOW(w),"6");
	gtk_container_set_border_width(GTK_CONTAINER(w),10);
	gtk_widget_set_size_request(w,300,200);
	g_signal_connect(w,"destroy",G_CALLBACK(gtk_main_quit),NULL);
	
	GtkWidget *v;
	v = gtk_vbox_new(FALSE,5);
	gtk_container_add(GTK_CONTAINER(w),v);
	
	GtkWidget *p;
	p = gtk_progress_bar_new();
	gtk_container_add(GTK_CONTAINER(v),p);

	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(p),0.5);	
	
	gtk_progress_bar_set_text(GTK_PROGRESS_BAR(p),"ok");

	GtkWidget *b1 = gtk_button_new_with_label("right to left");
	gtk_container_add(GTK_CONTAINER(v),b1);
	g_signal_connect(b1,"clicked",G_CALLBACK(toggle),p);
	
	GtkWidget *b2 = gtk_button_new_with_label("add");
	gtk_container_add(GTK_CONTAINER(v),b2);
	g_signal_connect(b2,"clicked",G_CALLBACK(callback),p);

	gtk_widget_show_all(w);
	
	gtk_main();
	return 0;
}
