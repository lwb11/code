/*给三个人投票，分别统计它们的得票数，并找出最高得票者*/

#include <stdio.h>
#include <string.h>     //字符串比较函数需要的头文件

struct jing    //定义结构体将人名和票数绑一块
{
	char *name;
	int shu;
};

void main ()

{
	struct jing one,two,three;
	one.name = "李";
	one.shu = 0;
	two.name = "张";
	two.shu = 0;
	three.name = "王";
	three.shu = 0;
	char a[30];   //注意定义输出字符串，只有字符串才能和字符串比较
	int i=0;
	printf("参加竞选的人:李,张,王");
	printf("\n\n");
	while (i<10)      //循环输入投票人名，统计
	{

		printf("输入要投给的人:  ");
		scanf("%s",a);
		printf("\n");
		
		if(strcmp(a, "李") == 0) //两个字符串比较函数，相等返回0
		{ 
			one.shu++; 
		} 
		else if(strcmp(a, "张") == 0) 
		{		 
			two.shu++; 
		} 
		else if(strcmp(a, "王") == 0) 
		{ 
			three.shu++; 	
		}
		i++;	
	}

	if (one.shu>=two.shu)   //比较找出得票最高的人
	{
		if (one.shu>=three.shu)
		{
			printf("最高得票者：%s\n",one.name);
		}
		else
		{
			printf("最高得票者：%s\n",three.name);
		}
	}
	else
	{
		if (one.shu>=three.shu)
		{
			printf("最高得票者：%s\n",two.name);
		}
		else
		{
			if (two.shu>three.shu)
			{
				printf("最高得票者：%s\n",two.name);
			}
			else
			{
				printf("最高得票者：%s\n",three.name);
			}
		}
	}
	printf("得票情况：%s,%d\n",one.name,one.shu);
	printf("得票情况：%s,%d\n",two.name,two.shu);
	printf("得票情况：%s,%d\n",three.name,three.shu);
//	printf("最高得票者：%s\n",*m);
}
