/*求平均成绩*/

#include <stdio.h>

void main ()

{
	int i,sum=0,j,a[2][3] = {{23,34,67},{87,56,88}};
	float avr;
	for (i=0;i<2;i++)
	{
		for (j=0;j<3;j++)
		{
			sum = sum + a[i][j];
		}
		avr = sum / 3;
		printf("%f\n",avr);
		sum = 0;
	}
	
}
