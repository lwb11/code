#include <stdio.h>

void main()
{
//	printf("%f\n",3.2/4);
//
//	printf("\n\n%d,%d\n",20/7,-20/7);
//	printf("%f,%F\n",20.0/7,-20.0/7);
//
	printf("%d\n",100%3);
}
