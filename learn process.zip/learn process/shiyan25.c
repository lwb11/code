#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct s 
{
	char a[10];
};

void main ()

{
	struct s *sss;
	ss = (struct s)malloc(10); 
	sss = &ss;
//	char a[10];
	printf("input\n");
	scanf("%s",&ss.a);
//	strcpy(ss->a,"aaaaa");
	printf("%s\n",sss->a);
}
