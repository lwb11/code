/*在100到200之间找出不能被三整除的*/

#include <stdio.h>

void main()

{
	int i;
	for (i=100;i<=200;i++)
	{
		if (0!=i%3)
		{
			printf("%d\n",i);
		}
	}
}
