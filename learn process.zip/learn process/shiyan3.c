/*简易计算器*/

#include <stdio.h>

void main()

{
	float a,c;
	char b;                   //字符型变量必须是char型
	printf("input two num:   ");
	scanf("%f%c%f",&a,&b,&c);
	switch (b)
		{
		case '+' :printf("%f\n",a+c);break;
		case '-' :printf("%f\n",a-c);break;
		case '*' :printf("%f\n",a*c);break;
		case '/' :printf("%f\n",a/c);break;
		}
}

