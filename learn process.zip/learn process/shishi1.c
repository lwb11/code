#if(0)

/*窗口相关的设置(大小,位置,可伸缩性,标题)*/
#include <gtk/gtk.h>

int main (int argc,char *argv[])
{
	gtk_init(&argc,&argv);

	GtkWidget *window;
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	gtk_window_set_title(GTK_WINDOW(window),"窗口");
	gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(window,400,300);
	gtk_window_set_resizable(GTK_WINDOW(window),FALSE);

	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);  //实现鼠标点击x退出的功能

	gtk_widget_show_all(window);

	gtk_main();
	return 0;
}
#endif

#if(0)

/*标签（添加标签、获取标签上的内容、设置标签上的内容）*/
#include <gtk/gtk.h>

int main(int argc,char*argv[])
{
	gtk_init(&argc,&argv);

	GtkWidget *window;
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(window),"标签");
	
	GtkWidget *v = gtk_vbox_new(TRUE,10);
	gtk_container_add(GTK_CONTAINER(window),v);

	GtkWidget *l1 = gtk_label_new("one");
	gtk_container_add(GTK_CONTAINER(v),l1);

	GtkWidget *l2 = gtk_label_new("I Love you");
	gtk_container_add(GTK_CONTAINER(v),l2);
	const char *s = gtk_label_get_label(GTK_LABEL(l2));
	printf("l2=%s\n",s);

	GtkWidget *l3 = gtk_label_new("牛牛牛");
	gtk_container_add(GTK_CONTAINER(v),l3);
	gtk_label_set_text(GTK_LABEL(l3),"true");

	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
	gtk_widget_show_all(window);

	gtk_main();
	return 0;
	
}
#endif

#if(1)

/*图片控件（创建、设置大小，更换）*/
#include <gtk/gtk.h>

int main(int argc,char *argv[])
{
	gtk_init(&argc,&argv);
	
        GtkWidget *window;
        window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_title(GTK_WINDOW(window),"图片控件");

	GtkWidget *h = gtk_hbox_new(TRUE,10);
	gtk_container_add(GTK_CONTAINER(window),h);
	//创建一个图片控件
	GtkWidget *jpg1 = gtk_image_new_from_file("./1.jpg");
	gtk_container_add(GTK_CONTAINER(h),jpg1);
	//通过pixbuf来改变图片的大小，但用完之后要释放资源
	GdkPixbuf *src = gdk_pixbuf_new_from_file("./2.jpg",NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src,100,100,GDK_INTERP_BILINEAR);
	GtkWidget *jpg2 = gtk_image_new_from_pixbuf(dst);
	//释放pixbuf用完的资源
	g_object_unref(src);
	g_object_unref(dst);
	gtk_container_add(GTK_CONTAINER(h),jpg2);
	//获取图片控件的pixbuf，并以这个pixbuf重新创建一个控件
	GdkPixbuf *tmp = gtk_image_get_pixbuf(GTK_IMAGE(jpg2));
	GtkWidget *jpg3 = gtk_image_new_from_pixbuf(tmp);
	gtk_container_add(GTK_CONTAINER(h),jpg3);
	//对1图的图片控件重新设置一张图片
	GtkWidget *jpg4 = gtk_image_new_from_file("./1.jpg");
	gtk_container_add(GTK_CONTAINER(h),jpg4);
	//更换图片更换为3.jpg
	src = gdk_pixbuf_new_from_file("./3.jpg",NULL);
	dst = gdk_pixbuf_scale_simple(src,200,200,GDK_INTERP_BILINEAR);
	gtk_image_set_from_pixbuf(GTK_IMAGE(jpg4),dst);

	gtk_widget_show_all(window);

	gtk_main();
	return 0;		
}
#endif
