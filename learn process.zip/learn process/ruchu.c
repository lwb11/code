#include <stdio.h>

void main()

{
//	int a=5;
//	float b=123.1234567;
//	double c=12345678.1234567;
//	char d='p';
//	printf("a=%d,%5d,%o,%x\n",a,a,a,a);
//	printf("b=%f,%lf,%1.4lf,%e\n",b,b,b,b);
//	printf("c=%lf,%f,%5.4lf\n",c,c,c);
//	printf("d=%c,%8c\n",d,d);
	
//	int a,b,c;
//	printf("input a,b,c\n");
//	scanf("%d%d%d",&a,&b,&c);
//	printf("a=%d,b=%d,c=%d\n",a,b,c);
	
	char a,b,c;
	printf("input char a,b,c:\n");
	scanf("%c %c %c",&a,&b,&c);
	printf("%d,%d,%d\n%c,%c,%c\n",a,b,c,a-32,b-32,c-32);
}
