/*把数组中的数按倒序的方式进行输出*/

#include <stdio.h>

void main ()

{
	int a[10],*p,i,j;

	for (j=0;j<=9;j++)
	{
		scanf("%d",&a[j]);
	}

	p = &a[0];

	for (i=9;i>=0;i--)
	{
		printf("%d\n",*(p+i));   //注意*p+i和*(p+i)的区别
	}
//	printf("%d\n",a[11]);
}
