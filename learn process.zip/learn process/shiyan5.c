/*任意输入三个数，将它们按从大到小的顺序排列（用指针和调用函数的方法）*/

#include <stdio.h>

void main()

{
	int a,b,c,maxx,minn,midd;
	printf("input three num:   ");
	scanf("%d,%d,%d",&a,&b,&c);
	
	int max (int a,int b,int c);
	int min (int a,int b,int c);
	int mid (int a,int b,int c);

	maxx = max(a,b,c);
	minn = min(a,b,c);
	midd = mid(a,b,c);
	printf("%d,%d,%d\n",maxx,midd,minn);
}

int max (int a,int b,int c)    //求最大的数

{
	int *max;
	if (a>b)
	{
		max = &a;
		if (a>c)
		{
			max = &a;
		}
		else
		{
			max = &c;
		}
	}
	else
	{
		max = &b;
		if (b>c)
		{
			max = &b;
		}
		else
		{
			max = &c;
		}
	}
	return *max;
}

int min (int a, int b,int c)    //求最小的数

{
	int *min;
	if (a<b)
	{
		min = &a;
		if (a<c)
		{
			min = &a;
		}
		else
		{
			min = &c;
		}
	}
	else
	{
		min = &b;
		if (b<c)
		{
			min = &b;
		}
		else
		{
			min = &c;
		}
	}
	return *min;
}

int mid (int a,int b,int c)     //求中间值

{
	int *mid,x,n;
	int max (int a,int b,int c);
	int min (int a,int b,int c);

	x = max (a,b,c);
	n = min (a,b,c);
	if (x != a && n != a)
	{
		mid = &a;
	}
	if (x != b && n != b)
	{
		mid = &b;
	}
	if (x != c && n != c)
	{
		mid = &c;
	}
	return *mid;
}
