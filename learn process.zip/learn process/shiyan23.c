/*简易链表制作（新建链表、删除链表指定结点、添加结点在指定位置）*/

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

#define NUM sizeof(struct student)   //定义一个长度，为后边的malloc函数使用

struct student *creat();             //创建链表函数
void shuchu(struct student *p);      //输出链表函数
void del(struct student *p);         //删除链表函数
void add(struct student *p);         //添加链表函数

struct student     
{
	long number;
	float chengji;
	struct student *next;
};

int n;      //定义全局变量，统计生成结点个数

void main ()
{
	struct student *stu;
	stu = creat();
	shuchu(stu);
	printf("\n");
	del(stu);
	add(stu);
}

void shuchu(struct student *p)
{
	struct student *head;
	head = p;
	if (p)                 //判断是否为空表
	{
		while (head)   //判断是否已到表尾
		{
			printf("%ld,%f\n",head->number,head->chengji);
			head = head->next;
		}
	}
	else
	{
		printf("nothing!\n");
	}
}

struct student *creat()
{
	struct student *head,*p1,*p2;
	p1 = p2 = (struct student *)malloc(NUM);   //新建结点，使p1,p2都指向新结点

	printf("input a number:  ");               //输入数据
	scanf("%ld",&p1->number);
	printf("input a chengji:  ");
	scanf("%f",&p1->chengji);
	
	head = NULL;
	n = 0;

	while (p1->number)                         //判断输入数据是否为0
	{
		n++;				   //结点数加一

		if (n == 1)
		{
			head = p1;                 //若为第一个结点，则将头指针指向该结点
		}
		else
		{
			p2->next = p1;             //若不是头结点，则将指针指向下一个结点
		}
		p2 = p1;                           //将p2移向新建的结点
		p1 = (struct student *)malloc(NUM);//用p1新建结点
		
		printf("input a number:  ");       //输入数据
		scanf("%ld",&p1->number);
		printf("input a chengji:  ");
		scanf("%f",&p1->chengji);
	}
	p2->next = NULL;                           //输入完数据，将最后结点的表尾指向NULL

	return head;                               //返回头指针，便于输出函数从头开始
}

void del (struct student *p)    //选择要删除的函数
{
	struct student *p1,*p2; //设置两个指针变量，是为了让一个保留在删除结点前，另一个移动寻找
	int c;
	if (p == NULL)    //先判断输入的链表是否为空表
	{
		printf("This is nothing!\n");
	}
	else
	{
		p1 = p;
		printf("input delete number: ");            //输入要删除的编号
		scanf("%d",&c);
     /*判断是否为要删除点并且判断是否已到链表表尾，若不满足，则指针变量向后移动寻找*/
		while(c != p1->number || p1->next == NULL)  
		{
			p2 = p1;
			p1 = p1->next;	
		}
		if (c == p1->number)
		{
			if (p1->next == NULL)  //判断是否为头结点
			{
				p = p1->next;  //删除头结点
			}
			else
			{
				p2->next = p1->next;  //删除中间符合条件的结点
			}
		}
		else
		{
			printf("not find!\n");
		}		
	}
	shuchu(p);     //调用函数，输出删除后的链表
	printf("\n");
}

void add(struct student *p)
{
	struct student *p1,*p2;
	struct student *stud;
	stud = (struct student *)malloc(NUM);
	printf("input add number:  ");
	scanf("%ld",&stud->number);
	printf("input add number:  ");
	scanf("%f",&stud->chengji);
	p1 = p;

	if (p == NULL)
	{
		p = stud;
		stud->next = NULL;
	} 
	else
	{
		while ((stud->number > p1->number) && (p1->next != NULL))
		{
			p2 = p1;
			p1 = p2->next;
		}
		if (stud->number <= p1->number)
		{
			if (p1 == p)
			{
				p = stud;
				stud->next = p1;
			}
			else
			{
				p2->next = stud;
				stud->next = p1;
			}
		}
		else
		{
			p1->next = stud;
			stud->next = NULL;
		}
	}
	n++;
	shuchu(p);
	printf("\n");
}
