/*在任意的3x3数组中，输入行号和列号，得出该行号列号所指的数*/

#include <stdio.h>

void main ()

{
	int i,j,n,m,a[3][3]={{1,2,3},{4,5,6},{7,8,9}},number,(*p)[3];
	printf("input some number:  ");
	p = a;
#if(1)
	for (n=0;n<3;n++)
	{
		for (m=0;m<3;m++)
		{
			scanf("%d",&a[n][m]);
		}
	}
#endif	
	printf("input i,j:  ");    //注意输入行号列号时，从0开始，因为c中的数组定义都是从0开始
	scanf("%d,%d",&i,&j);
	
	int shuchu (int (*p)[3],int x,int y);  //函数调用二维数组注意，多查一下

	number = shuchu (p,i,j);
	printf("number=%d,i=%d,j=%d\n",number,i,j);
	printf("a[%d][%d]=%d\n",i,j,*(*(p+i)+j));
	for (n=0;n<3;n++)
	{
		for (m=0;m<3;m++)
		{
			printf("%d    ",a[n][m]);
		}
	printf("\n");
	}
}
#if(1)
int shuchu (int (*p)[3],int x,int y)
{
	int k;
	
	if (x>3 || x<0)
	{
		printf("error!\n");
	}
	if (y>3 || y<0)
	{
		printf("error!\n");
	}
	k = *(*(p+x)+y);  //等价于*(a[x]+y)
	return k;
}
#endif
