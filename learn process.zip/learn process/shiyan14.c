/*任意输入一个数，求出它的阶乘*/

#include <stdio.h>

void main ()

{
	int n,a;
	printf("input a number:  ");
	scanf("%d",&n);

	int jiecheng (int x);
	a = jiecheng (n);
	
	printf("%d\n",a);
}

int jiecheng (int x)
{
	int b;
	if (x < 0)
	{
		printf("input error!");
	}
	else if (x == 0 || x == 1)   //x=0的条件是考虑到0！=1
	{
		b = 1;
	}
	else
	{	
		b = jiecheng (x-1)*x;    //递归的关键，好好理解一下
	}
	return b;
}
