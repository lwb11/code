/*学生管理系统（包括创建，增添，删除，修改，查看功能）*/

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

#define NUM sizeof(struct student)

struct student *creat();             //创建链表函数
void shuchu(struct student *p);      //输出链表函数
void add(struct student *p);         //增加链表函数
void del(struct student *p);         //删除链表函数
void modify(struct student *p);      //修改链表函数
void see(struct student *p);         //查看链表函数

struct student
{
	long num;
	char name[10];
	char sex[5];
	float grade;
	struct student *next;
};

int n;

void main ()
{
	int a=9,b;
	struct student *stu,*p;
	printf("================================================\n");
	printf("|   编号    |   姓名   |   性别   |    成绩    |\n");
	printf("================================================\n");
	printf("|           |          |          |            |\n");
	printf("================================================\n");
	while(a)
	{
		printf("选择编辑表格方式：\n");
		printf("0--退出编辑，1--创建用户，2--增加用户\n");
		printf("3--删除用户，4--修改用户，5--查看用户\n");
		scanf("%d",&a);
		switch(a)
		{
			case 0:break;
			case 1:printf("是否要创建新的表格？(0--NO，1--YES)\n");
				scanf("%d",&b);
				if (b == 1)
				{
					stu = creat();shuchu(stu);
				}break;
			case 2:add(p);break;
			case 3:if (p == NULL)
				{
					printf("This is empty！\n");
				}
				else
				{
					del(p);
				}break;
			case 4:if (p == NULL)
				{
					printf("THis is empty！\n");
				}
				else
				{
					modify(p);
				}break;
			case 5:see(p);break;
		}
		p = stu;
	}
}
/*********************************************************************************/
/*********************************************************************************/
void shuchu(struct student *p)   //输出函数
{
	struct student *head;
	head = p;
	if (p)
	{	
		printf("================================================\n");
		printf("|   编号    |   姓名   |   性别   |    成绩    |\n");
		printf("================================================\n");
		while (head)
		{
			printf("|   %ld    |    %s    |    %s    |    %4.2f   |\n",head->num,head->name,head->sex,head->grade);
			head = head->next;
		}
	}
	else
	{
		printf("该表为空表！\n");
	}
	printf("================================================\n");
	printf("\n");
}
/*********************************************************************************/
/*********************************************************************************/
struct student *creat()         //创建函数
{
        struct student *head,*p1,*p2;
        p1 = p2 = (struct student *)malloc(NUM);   //新建结点，使p1,p2>都指向新结点
        printf("学号：");               //输入数据
        scanf("%ld",&p1->num);
	printf("姓名：");
	scanf("%s",p1->name);
	printf("性别：");
	scanf("%s",p1->sex);
        printf("成绩：");
        scanf("%f",&p1->grade);

        head = NULL;
        n = 0;

        while (p1->num)                         //判断输入数据是否为0
        {
                n++;                               //结点数加一

                if (n == 1)
                {
                        head = p1;                
                }
                else
                {
                        p2->next = p1;             
                }
                p2 = p1;                           //将p2移向新建的结点
                p1 = (struct student *)malloc(NUM);//用p1新建结点
        	printf("学号：");               //输入数据
        	scanf("%ld",&p1->num);
		printf("姓名：");
		scanf("%s",p1->name);
		printf("性别：");
		scanf("%s",p1->sex);
        	printf("成绩：");
        	scanf("%f",&p1->grade);
        }
        p2->next = NULL;                        
        
	return head;                              
}
/*********************************************************************************/
/*********************************************************************************/
void del (struct student *p)    //删除函数
{
        struct student *p1,*p2; //设置两个指针变量，是为了让一个保留在>删除结点前，另一个移动寻找
        int c;
        if (p == NULL)    //先判断输入的链表是否为空表
        {
                printf("This is empty!\n");
        }
        else
        {
                p1 = p;
                printf("输入要删除的学号\n");            //输入要删>除的编号
                scanf("%d",&c);
     /*判断是否为要删除点并且判断是否已到链表表尾，若不满足，则指针变量向后移动寻找*/
                while((c != p1->num) && (p1->next != NULL))
                {
                        p2 = p1;
                        p1 = p1->next;
                }
                if (c == p1->num)
                {
                        if (p1->next == NULL)  //判断是否为头结点
                        {
                                p = p1->next;  //删除头结点
                        }
                        else
                        {
                                p2->next = p1->next;  //删除中间符合条>件的结点
                        }
                }
                else
                {
                        printf("not find!\n");
                }
        }
        shuchu(p);     //调用函数，输出删除后的链表
}
/*********************************************************************************/
/*********************************************************************************/
void add(struct student *p)     //添加函数
{
        struct student *p1,*p2;
        struct student *stud;
        stud = (struct student *)malloc(NUM);
        printf("学号：");               //输入数据
        scanf("%ld",&stud->num);
	printf("姓名：");
	scanf("%s",stud->name);
	printf("性别：");
	scanf("%s",stud->sex);
        printf("成绩：");
        scanf("%f",&stud->grade);
        p1 = p;

        if (p == NULL)
        {
                p = stud;
                stud->next = NULL;
        }
        else
        {
                while ((stud->num > p1->num) && (p1->next != NULL))
                {
                        p2 = p1;
                        p1 = p2->next;
                }
                if (stud->num <= p1->num)
               {
                        if (p1 == p)
                        {
                                p = stud;
                                stud->next = p1;
                        }
                        else
                        {
                                p2->next = stud;
                                stud->next = p1;
                        }
                }
                else
                {
                        p1->next = stud;
                        stud->next = NULL;
                }
        }
        n++;
        shuchu(p);
        printf("\n");
}
/*********************************************************************************/
/*********************************************************************************/
void modify(struct student *p)  //修改函数
{
	struct student *p1,*p2;
	int a;
	
	if (p == NULL)
	{
		printf("该表位空表！\n");
	}
	else
	{
		printf("输入要修改的编号：\n");
		scanf("%d",&a);
		p1 = p;
		
		while ((a != p1->num) && (p1->next != NULL))
		{
			p2 = p1;
			p1 = p1->next;
		}
		if (a == p1->num)
		{	
//        		struct student *stud;
//        		stud = (struct student *)malloc(NUM);
        		printf("修改后学号：");               //输入数据
        		scanf("%ld",&p1->num);
			printf("修改后姓名：");
			scanf("%s",p1->name);
			printf("修改后性别：");
			scanf("%s",p1->sex);
        		printf("修改后成绩：");
        		scanf("%f",&p1->grade);
//			p1 = stud;
			
			printf("================================================\n");
			printf("|   编号    |   姓名   |   性别   |    成绩    |\n");
			printf("================================================\n");
			printf("|    %d    |    %s    |    %s    |    %4.2f   |\n",p1->num,p1->name,p1->sex,p1->grade);
		}
		else
		{
			printf("查无此编号！\n");
		}
	printf("================================================\n");
	}
	shuchu(p);
}
/*********************************************************************************/
/*********************************************************************************/
void see(struct student *p)     //查看函数
{
	struct student *p1,*p2;
	int a;
	
	if (p == NULL)
	{
		printf("该表为空表！\n");
	}
	else
	{
		printf("输入要查看的编号：\n");
		scanf("%d",&a);
		p1 = p;
		
		while ((a != p1->num) && (p1->next != NULL))
		{
			p2 = p1;
			p1 = p1->next;
		}
		if (a == p1->num)
		{	
			printf("================================================\n");
			printf("|   编号    |   姓名   |   性别   |    成绩    |\n");
			printf("================================================\n");
			printf("|    %d    |    %s    |    %s    |    %4.2f   |\n",p1->num,p1->name,p1->sex,p1->grade);
		}
		else
		{
			printf("查无此编号！\n");
		}
	printf("================================================\n");
	}
}
