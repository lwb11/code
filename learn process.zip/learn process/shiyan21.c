/*输入两个数，通过选择运行方式得到不同结果*/
#if(0)
#include <stdio.h>

void main ()

{
	int a,b,n;
	printf("输入两个数：  ");
	scanf("%d,%d",&a,&b);
	
	int zuida (int a,int b);
	int zuixiao (int a,int b);
	int he (int a,int b);
	void funny (int n,int a,int b);
	
	printf("选择调用方式1,2,3： ");
	scanf("%d",&n);
	while (n!=1 && n!=2 && n!=3)
	{
		printf("重新选择方式： ");
		scanf("%d",&n);
	}
	funny(n,a,b);
}
void funny (int n,int a,int b)
{
	int max,min,add;
	if (n == 1)
	{
		max = zuida (a,b);
		printf("max=%d\n",max);
	}
	if (n == 2)
	{
		min = zuixiao (a,b);
		printf("min=%d\n",min);
	}
	if (n == 3)
	{
		add =he (a,b);
		printf("add=%d\n",add);
	}
}
	
int zuida (int a,int b)
{
	int max;
	if (a>b)
	{
		max=a;
	}
	else
	{
		max=b;
	}
	return max;
}
int zuixiao (int a,int b)
{
	int min;
	if (a>b)
	{
		min=b;
	}
	else
	{
		min=a;
	}
	return min;
}
int he (int a,int b)
{
	int add;
	add = a+b;
	return add;
}
#endif
/*输入两个数，用指向函数的指针来分别运行不同的调用结果*/
#if(1)
#include <stdio.h>

void main ()

{
	int a,b,n;
	printf("输入两个数：  ");
	scanf("%d,%d",&a,&b);
	
	int zuida (int a,int b);
	int zuixiao (int a,int b);
	int he (int a,int b);
	void funny (int a,int b,int (*p)(int,int));

	funny(a,b,zuida);
	funny(a,b,zuixiao);
	funny(a,b,he);
}
int zuida (int a,int b)
{
	int max;
	if (a>b)
	{
		max=a;
	}
	else
	{
		max=b;
	}
	return max;
}
int zuixiao (int a,int b)
{
	int min;
	if (a>b)
	{
		min=b;
	}
	else
	{
		min=a;
	}
	return min;
}
int he (int a,int b)
{
	int add;
	add = a+b;
	return add;
}
void funny (int a,int b,int (*p)(int,int))
{
	int max,min,add;
	if (p==zuida)
	{
		max = zuida (a,b);
		printf("max=%d\n",max);
	}
	if (p==zuixiao)
	{
		min = zuixiao (a,b);
		printf("min=%d\n",min);
	}
	if (p==he)
	{
		add = he (a,b);
		printf("add=%d\n",add);
	}
}
#endif
