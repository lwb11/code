/*输出数组中的全部元素（用指针的方法）*/

#include <stdio.h>

void main ()

{
	int a[10],*p,i,j;
	
	for (j=0;j<=9;j++)
	{
		scanf("%d",&a[j]);
	}
	
	printf("\n");
	p = &a[0];

	for (i=0;i<=9;i++)
	{
		printf("%d",*(p+i));
	}
}
