/*三个数按从大到小的顺序排列*/

#include <stdio.h>

void main()

{
	int a,b,c,max,min,mid;
	printf("input three num:   ");
	scanf("%d,%d,%d",&a,&b,&c);
	if (a>b)
	{
		max = a;
		min = b;
		if (a>c)
		{
		max=a;
			if (b>c)
			{
			min = c;
			mid = b;
			}
			else 
			{
			min = b;
			mid = c;
			}
		}
		else 
		{
			max=c;
			mid=a;
			min=b;
		}
	}
	printf("%d,%d,%d\n",max,mid,min);
}
