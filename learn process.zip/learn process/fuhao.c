#include <stdio.h>

void main()

{
//	int x,y,i=5,n=5;
//	x = i++;
//	y = ++n;
//	printf("x=%d,i=%d\n",x,i);
//	printf("y=%d,n=%d\n",y,n);
//	printf("++i=%d\n",++i);
//	printf("--i=%d\n",--i);
//	printf("i++=%d\n",i++);
//	printf("i--=%d\n",i--);
//	printf("-i++=%d\n",-i++);
//	printf("-i--=%d\n",-i--);
//
//	int i=5,j=5,p,q,m,n;
//	p=(i++)+(i++)+(i++);
//	q=(++j)+(++j)+(++j);
//	m=i+++i+++i++;
//	n=++j+++j+++j;
//	printf("p=%d\n,q=%d\n",p,q);

	int a=2, b=4, c=6, x,y;
	y = (a+c,b+c);
	printf("y=%d\nx=%d\n",y,x);
}
