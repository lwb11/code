/*任意输入四个数，输出能组成的互不相同且无重复数字的三位数*/

#include <stdio.h>

void main ()

{
	int i,j,k,a[3];
	printf("input four number:   ");
	scanf("%d,%d,%d,%d",&a[0],&a[1],&a[2],&a[3]);
	
	for (i=0;i<4;i++)
	{
//		switch (i)
//		{
//		   case 1:i=a;break;
//		   case 2:i=b;break;
//		   case 3:i=c;break;
//		   case 4:i=d;break;
//		}
//		printf("i=%d",i);
		for (j=0;j<4;j++)
		{	
//			switch (j)
//			{
//			   case 1:j=a;break;
//		  	   case 2:j=b;break;
//		  	   case 3:j=c;break;
//		  	   case 4:j=d;break;
//			}
//			printf("j=%d",j);
			for (k=0;k<4;k++)
			{
				
//				switch (k)
//				{
//		  		   case 1:k=a;break;
//		 		   case 2:k=b;break;
//		 		   case 3:k=c;break;
//		  		   case 4:k=d;break;
//				}
//				printf("k=%d",k);
				if (i != j && i != k && j != k)
				{
					printf("%d%d%d\n",a[i],a[j],a[k]);//printf语句中，引号中的逗号可省，后边的不可省。
				}
			}
		}

	}

			//	if (i != j && i != k && j != k)
			//	{		
			//		printf("%d,%d,%d\n",i,j,k);
			//	}
/*1，2，3，4四个数组成的互不相同且无重复数字的三位数的程序*/
//	int i,j,k;
//	for (i=1;i<5;i++)
//	{
//		for (j=1;j<5;j++)
//		{
//			for (k=1;k<5;k++)
//			{
//				if (i!=j && i!=k && j!=k)
//				{
//				    printf("%d,%d,%d\n",i,j,k);
//				}
//			}
//		}
//	}
}
