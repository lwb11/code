#include <stdio.h>

void main()
{
	float a = 5.5;
	printf("(int)a=%d,a=%f\n",(int)a,a);//强制转化只是针对当前语句
}
