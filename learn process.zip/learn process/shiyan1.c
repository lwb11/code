/*判断闰年的程序*/

#include <stdio.h>

void main()

{
	int a,b,c,d;
	printf("input a year:   ");
	scanf("%d",&a);
	b = a % 4;
	c = a % 100;
	d = a % 400;
	if (b == 0)
	{
		if (c != 0)
		{
		printf("Yes\n");
		}
		else
		{
			if (d == 0)
			{
			printf("Yes\n");
			}
			else
			{
			printf("No\n");
			}
		}
	}
	else 
	{
		printf("Yes\n");
	}
}
