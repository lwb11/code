#if(1)
#include <gtk/gtk.h>

int main (int argc,char *argv[])

{
        GtkBuilder *builder;
        gtk_init(&argc,&argv);  //初始化GTK程序

        builder = gtk_builder_new(); 

	if (!gtk_builder_add_from_file(builder,"./first.glade",NULL))
	{
		printf("connot load file!");
	}
	GtkWidget *w = GTK_WIDGET(gtk_builder_get_object(builder,"linux"));
	
	GtkButton *b = GTK_BUTTON(gtk_builder_get_object(builder,"linux_1"));
        
	const char *t = gtk_button_get_label(b);

	printf("t=%s\n",t);

        gtk_widget_show_all(w);  //显示窗口

        gtk_main();                    //GTK必不可少的函数

        return 0;
}
#endif
