/*向数组中输入10个数，找出其中最大和最小的数*/

#include <stdio.h>

void main ()

{
	int a[10],i,max,min;
	printf("input some number:  ");	
	int zuida (int a[],int n);        //记得数组函数定义时的格式
	int zuixiao (int a[],int n);	

	for (i=0;i<=9;i++)
	{
		scanf("%d",&a[i]);
	}

	max = zuida(a,10);
	min = zuixiao(a,10);

	printf("%d,%d\n",max,min);
}

int zuida (int a[],int n)      //计算最大值
{
	int *p,i,max=a[0];
	p = &a[0];
	
	for (i=0;i<n;i++)
	{
		if (*(p+i)>max)
		{
			max = *(p+i);	
		}
	}
	return max;
}

int zuixiao (int a[],int n)    //计算最小值
{
	int *p,i,min=a[0];
	p = &a[0];
	
	for (i=0;i<n;i++)
	{
		if (*(p+i)<min)
		{
			min = *(p+i);	
		}
	}
	return min;
}
