
/*任意输入两个数，计算出他们平方后数的阶乘，之后求出两数的和*/

#include <stdio.h>

void main ()

{
	int a,b,sum=0,n,m;
	printf("input number:  ");
	scanf("%d,%d",&n,&m);
	int pingfang (int x);
	int jiecheng (int y);

	a = pingfang (n);
	b = pingfang (m);
	sum = a + b;
	printf("%d\n",sum);
}

int pingfang (int x)

{
	int c,d;
	c = x * x;
	
	int jiecheng (int y);
	d = jiecheng (c);

	return d;
}

int jiecheng (int y)

{
	int i,c=1;
			
	while (y)
	{
		c = y*c;
		y--;
	}
	return c;
}
