/*学生管理系统（增删查改）GTK*/

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "sqlite3.h"

    GtkWidget *entry11 = NULL;
    GtkWidget *entry22 = NULL;
    GtkWidget *entry33 = NULL;
    sqlite3 *db = NULL;

void callback_1(GtkButton *button,gpointer user_data) 
{
	char **resultp;
	int nrow;
	int ncolumn;
    	const char *entry_1;
    	const char *entry_2;
    	char sql[100];
	
	entry_1 = gtk_entry_get_text(GTK_ENTRY(entry11));
    	entry_2 = gtk_entry_get_text(GTK_ENTRY(entry22));

	sprintf(sql,"select * from root_info where user_name = '%s' and password = '%s';",entry_1,entry_2);
	printf("%s \n",sql);

    	int result = 0;
    	char *errmsg = NULL;
	result = sqlite3_open("test.db",&db);

	if(result!=SQLITE_OK)
    	{
        	printf("open error\n");
        	return -1;
    	}
    	else
	{
		 printf("succes\n");
	}
	sqlite3_get_table(db,sql,&resultp,&nrow,&ncolumn,&errmsg);
    	printf("%d\n",nrow);
    	printf("%d\n",ncolumn);
	if(nrow == 1 && ncolumn == 3)
	{
		printf("====%d\n",nrow);
		printf("====%d\n",ncolumn);
		gtk_widget_hide_all(user_data);
		menu();
		printf("登陆\n");
    		sqlite3_close(db);
	}
	else
	{
		printf("%d\n",nrow);
	        printf("%d\n",ncolumn);
	        printf("登陆失败");
	        login_warning();
		sqlite3_close(db);
	}
}

void callback_2(GtkButton *button,gpointer user_data)
{
	insert_view();
}

void callback_3(GtkButton *button,gpointer user_data)
{
	select_view();
}

void callback_4(GtkButton *button,gpointer user_data)
{
	delete_view();
}

void callback_5(GtkButton *button,gpointer user_data)
{
	update_view();
}

void callback_insert(GtkButton *button,gpointer user_data)
{
	printf("insert\n");
	const char * entry_1;
	const char * entry_2;
	const char * entry_3;
	char sql[100];
	entry_1 = gtk_entry_get_text(GTK_ENTRY(entry11));
	entry_2 = gtk_entry_get_text(GTK_ENTRY(entry22));
	entry_3 = gtk_entry_get_text(GTK_ENTRY(entry33));
	int n = atoi(entry_1);
	int j = atoi(entry_3);
	sprintf(sql,"insert into user_info values(%d,'%s',%d);",n,entry_2,j); //实现向sql里写入数据
	printf("%s \n",sql);
	int result = 0;
	char *errmsg = NULL;
	result = sqlite3_open("test.db",&db);

	if(result!=SQLITE_OK)
	{
        	printf("open error\n");
		return -1;
    	}
    	else
	{
		printf("succes");
	}
    	int ret=sqlite3_exec(db,sql,NULL,NULL,&errmsg);
	if(ret == SQLITE_OK)
    	{
		printf("录入成功\n");
    	}
    	sqlite3_close(db);
}

void callback_delete(GtkButton *button,gpointer user_data)
{
	const char * entry_1;
    	char sql[100];
    	entry_1 = gtk_entry_get_text(GTK_ENTRY(entry11));
    	int n =atoi(entry_1);
    	sprintf(sql,"delete from user_info where id = %d;",n);
    	printf("%s\n",sql);
    	int result = 0;
    	char *errmsg = NULL;
    	result = sqlite3_open("test.db",&db);
	if(result!=SQLITE_OK)
	{
		printf("open error\n");
        	return -1;
	}
	else
	{
		printf("succes");
	}
	int ret=sqlite3_exec(db,sql,NULL,NULL,&errmsg);
    	if(ret == SQLITE_OK)
	{
		printf("删除成功\n");
	}
	sqlite3_close(db);
}

void callback_update(GtkButton *button,gpointer user_data)
{
	const char * entry_1;
    	const char * entry_2;
    	const char * entry_3;
    	char sql[100];
    	entry_1 = gtk_entry_get_text(GTK_ENTRY(entry11));
    	entry_2 = gtk_entry_get_text(GTK_ENTRY(entry22));
    	entry_3 = gtk_entry_get_text(GTK_ENTRY(entry33));
    	int n = atoi(entry_1);
    	int j = atoi(entry_3);
    	sprintf(sql,"update user_info set grade = %d,name = '%s' where id =%d ;",j,entry_2,n);
    	printf("%s \n",sql);
    	int result = 0;
    	char *errmsg = NULL;
    	result = sqlite3_open("test.db",&db);
	if(result!=SQLITE_OK)
	{
		printf("open error\n");
        	return -1;
	}
	else
	{
		printf("succes");
	}
	int ret=sqlite3_exec(db,sql,NULL,NULL,&errmsg);
    	if(ret == SQLITE_OK)
	{
		printf("更新成功\n");
	}
	sqlite3_close(db);
}

int result_find(void *para,int ncolumn,char ** columnvalue,char *columnname[])
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	GtkWidget *table = gtk_table_new(4, 6, TRUE);
    	gtk_widget_set_size_request(window,600,500);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	gtk_container_add(GTK_CONTAINER(window), table);

    	int i;
    	char nlable[100];

    	GtkWidget *label_1;
    	GtkWidget *label_2;
	for(i = 0;i < ncolumn; i++)
	{
		label_1 = gtk_label_new("123 ");
        	gtk_label_set_text(GTK_LABEL(label_1),columnname[i] );
        	gtk_table_attach_defaults(GTK_TABLE(table),label_1, 2,3, i+1, i+2);
        	label_2 = gtk_label_new("123 ");
        	gtk_label_set_text(GTK_LABEL(label_2),columnvalue[i]);
        	gtk_table_attach_defaults(GTK_TABLE(table),label_2, 3,4, i+1, i+2);
	}
	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    	gtk_widget_show_all(window);
    	gtk_main();

	return 0;
}

void callback_select_view(GtkButton *button,gpointer user_data)
{
	const char * entry_1;
    	char sql[100];
    	entry_1 = gtk_entry_get_text(GTK_ENTRY(entry11));
    	int n =atoi(entry_1);
    	sprintf(sql,"select * from user_info where id = %d;",n);
    	printf("%s\n",sql);
    	int result = 0;
    	char *errmsg = NULL;
    	result = sqlite3_open("test.db",&db);
    	if(result!=SQLITE_OK)
	{
		printf("open error\n");
        	return -1;
	}
	else
	{
		printf("succes");
	}
	int ret=sqlite3_exec(db,sql,result_find,NULL,&errmsg);
    	if(ret == SQLITE_OK)
	{
		printf("查询成功\n");
	}
	sqlite3_close(db);
}

int main(int argc,char *argv[])
{ 
	gtk_init(&argc,&argv);
   	login();
 
   	return 0;
}

void login(int argc,char *argv[])
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	GtkWidget *table = gtk_table_new(5,5,TRUE);
    	gtk_widget_set_size_request(window,500,300);
    	gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    	GtkWidget *label1 = gtk_label_new("学 生 管 理 系 统");
    	GtkWidget *label2 = gtk_label_new("版本：lwb 0.0");
    	GtkWidget *label3 = gtk_label_new("user");
    	GtkWidget *label4 = gtk_label_new("password");


    	entry11 = gtk_entry_new();
    	entry22 = gtk_entry_new();
    	GtkWidget *button1 = gtk_button_new_with_label("登陆");

    	gtk_entry_set_text(GTK_ENTRY(entry11),"请输入用户名");
    	gtk_entry_set_text(GTK_ENTRY(entry22),"请输入密码");
    	gtk_entry_set_visibility(GTK_ENTRY(entry22),FALSE);
	
	gtk_container_add(GTK_CONTAINER(window),table);
    	gtk_table_attach_defaults(GTK_TABLE(table),label1,0,5,0,1);
    	gtk_table_attach_defaults(GTK_TABLE(table),label3,0,1,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),label4,0,1,2,3);
    	gtk_table_attach_defaults(GTK_TABLE(table),label2,0,5,4,5);

    	gtk_table_attach_defaults(GTK_TABLE(table),entry11,1,4,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),entry22,1,4,2,3);

    	gtk_table_attach_defaults(GTK_TABLE(table),button1,1,4,3,4);


    	g_signal_connect(button1,"pressed",G_CALLBACK(callback_1),window);

    	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    	gtk_widget_show_all(window);
    	gtk_main();
}

void menu(int argc,char *argv[])      //菜单
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	GtkWidget *table = gtk_table_new(7,7,TRUE);
    	gtk_widget_set_size_request(window,700,500);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");

    	GtkWidget *label1 = gtk_label_new("功能列表");
    	GtkWidget *label2 = gtk_label_new("版本：lwb 0.0");
    	GtkWidget *label3 = gtk_label_new("haha");
    
        GtkWidget *button2 = gtk_button_new_with_label("增添学生信息");
        GtkWidget *button3 = gtk_button_new_with_label("查询学生信息");
        GtkWidget *button4 = gtk_button_new_with_label("删除学生信息");
        GtkWidget *button5 = gtk_button_new_with_label("更新学生信息");
    
        gtk_container_add(GTK_CONTAINER(window),table);
        gtk_table_attach_defaults(GTK_TABLE(table),label1,0,7,0,1);
//	gtk_table_attach_defaults(GTK_TABLE(table),label3,1,7,1,7);
    
        gtk_table_attach_defaults(GTK_TABLE(table),button2,0,7,2,3);
       	gtk_table_attach_defaults(GTK_TABLE(table),button3,0,7,3,4);
        gtk_table_attach_defaults(GTK_TABLE(table),button4,0,7,4,5);
        gtk_table_attach_defaults(GTK_TABLE(table),button5,0,7,5,6);
	gtk_table_attach_defaults(GTK_TABLE(table),label2,0,7,6,7);

	g_signal_connect(button2,"pressed",G_CALLBACK(callback_2),window);
    	g_signal_connect(button3,"clicked",G_CALLBACK(callback_3),window);
    	g_signal_connect(button4,"clicked",G_CALLBACK(callback_4),window);
    	g_signal_connect(button5,"clicked",G_CALLBACK(callback_5),window);


    	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    	gtk_widget_show_all(window);
   	gtk_main();
}

void insert_view(int argc,char *argv[])    //添加
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	GtkWidget *table = gtk_table_new(5,6,TRUE);
    	gtk_widget_set_size_request(window,600,500);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    	entry11 = gtk_entry_new();
    	entry22 = gtk_entry_new();
    	entry33 = gtk_entry_new();

//    	GtkWidget entry_s [4] = {entry1,entry2,entry3};
    
        gtk_entry_set_text(GTK_ENTRY(entry11),"*****");
        gtk_entry_set_text(GTK_ENTRY(entry22),"****");
        gtk_entry_set_text(GTK_ENTRY(entry33),"**");
    
        GtkWidget *label1 = gtk_label_new("id");
        GtkWidget *label2 = gtk_label_new("name");
        GtkWidget *label3 = gtk_label_new("grade");
        GtkWidget *label4 = gtk_label_new("输入添加信息");
        GtkWidget *label5 = gtk_label_new("lwb 0.0");
    
        GtkWidget *button1 = gtk_button_new_with_label("提交");

	gtk_container_add(GTK_CONTAINER(window),table);
    	gtk_table_attach_defaults(GTK_TABLE(table),label4,0,5,0,1);
    	gtk_table_attach_defaults(GTK_TABLE(table),label1,0,1,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),label2,0,1,2,3);
    	gtk_table_attach_defaults(GTK_TABLE(table),label3,0,1,3,4);
    	gtk_table_attach_defaults(GTK_TABLE(table),label5,0,5,5,6);

    	gtk_table_attach_defaults(GTK_TABLE(table),entry11,1,4,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),entry22,1,4,2,3);
    	gtk_table_attach_defaults(GTK_TABLE(table),entry33,1,4,3,4);

    	gtk_table_attach_defaults(GTK_TABLE(table),button1,1,4,4,5);

	g_signal_connect(button1,"pressed",G_CALLBACK(callback_insert),window);

    	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    	gtk_widget_show_all(window);
    	gtk_main();
}

void delete_view(int argc,char *argv[])  //删除
{
	
    	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	GtkWidget *table = gtk_table_new(5,4,TRUE);
    	gtk_widget_set_size_request(window,600,400);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    	entry11 = gtk_entry_new();
    	gtk_entry_set_text(GTK_ENTRY(entry11),"****");

    	GtkWidget *label1 = gtk_label_new("id");
    	GtkWidget *label2 = gtk_label_new("输入要删除人的id");
    	GtkWidget *label3 = gtk_label_new("lwb 0.0");

    	GtkWidget *button1 = gtk_button_new_with_label("提交");

    	gtk_container_add(GTK_CONTAINER(window),table);
    	gtk_table_attach_defaults(GTK_TABLE(table),label2,0,5,0,1);
    	gtk_table_attach_defaults(GTK_TABLE(table),label1,0,1,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),label3,0,5,3,4);
    	gtk_table_attach_defaults(GTK_TABLE(table),entry11,1,4,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),button1,1,4,2,3);

	g_signal_connect(button1,"clicked",G_CALLBACK(callback_delete),window);

    	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    	gtk_widget_show_all(window);
    	gtk_main();
}

void update_view(int argc,char *argv[])  //更新
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	GtkWidget *table = gtk_table_new(5,6,TRUE);
    	gtk_widget_set_size_request(window,600,500);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    	entry11 = gtk_entry_new();
    	entry22 = gtk_entry_new();
    	entry33 = gtk_entry_new();

    	gtk_entry_set_text(GTK_ENTRY(entry11),"*****");
    	gtk_entry_set_text(GTK_ENTRY(entry22),"****");
    	gtk_entry_set_text(GTK_ENTRY(entry33),"**");

    	GtkWidget *label1 = gtk_label_new("id");
    	GtkWidget *label2 = gtk_label_new("name");
    	GtkWidget *label3 = gtk_label_new("grade");
    	GtkWidget *label4 = gtk_label_new("输入更新信息");
    	GtkWidget *label5 = gtk_label_new("lwb 0.0");

	GtkWidget *button1 = gtk_button_new_with_label("提交");

    	gtk_container_add(GTK_CONTAINER(window),table);
    	gtk_table_attach_defaults(GTK_TABLE(table),label4,0,5,0,1);
    	gtk_table_attach_defaults(GTK_TABLE(table),label1,0,1,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),label2,0,1,2,3);
    	gtk_table_attach_defaults(GTK_TABLE(table),label3,0,1,3,4);
    	gtk_table_attach_defaults(GTK_TABLE(table),label5,0,5,5,6);

    	gtk_table_attach_defaults(GTK_TABLE(table),entry11,1,4,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),entry22,1,4,2,3);
    	gtk_table_attach_defaults(GTK_TABLE(table),entry33,1,4,3,4);

    	gtk_table_attach_defaults(GTK_TABLE(table),button1,1,4,4,5);
	
    	g_signal_connect(button1,"clicked",G_CALLBACK(callback_update),window);
	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);

    	gtk_widget_show_all(window);
    	gtk_main();
}

select_view(int argc,char *argv[])   //查询
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	GtkWidget *table = gtk_table_new(5,4,TRUE);
    	gtk_widget_set_size_request(window,600,400);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    	entry11 = gtk_entry_new();
    	gtk_entry_set_text(GTK_ENTRY(entry11),"*****");

    	GtkWidget *label1 = gtk_label_new("id");
    	GtkWidget *label2 = gtk_label_new("输入要查询人的id");
    	GtkWidget *label3 = gtk_label_new("lwb 0.0");

    	GtkWidget *button1 = gtk_button_new_with_label("查询");

    	gtk_container_add(GTK_CONTAINER(window),table);
    	gtk_table_attach_defaults(GTK_TABLE(table),label2,0,5,0,1);
    	gtk_table_attach_defaults(GTK_TABLE(table),label1,0,1,1,2);
    	gtk_table_attach_defaults(GTK_TABLE(table),label3,0,5,3,4);

    	gtk_table_attach_defaults(GTK_TABLE(table),entry11,1,4,1,2);

    	gtk_table_attach_defaults(GTK_TABLE(table),button1,1,4,2,3);

	g_signal_connect(button1,"clicked",G_CALLBACK(callback_select_view),window);

    	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);

    	gtk_widget_show_all(window);
    	gtk_main();
}

login_warning(int argc,char *argv[])   //提示
{
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    	gtk_widget_set_size_request(window,400,400);
    	gtk_window_set_title(GTK_WINDOW(window), "Student Manger System");
    	gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    	GtkWidget *label = gtk_label_new("用户名或者密码错误！");
    	gtk_container_add(GTK_CONTAINER(window),label);
    	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    	gtk_widget_show_all(window);
    	gtk_main();
}
