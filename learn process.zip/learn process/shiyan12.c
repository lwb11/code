
/*统计输入字符的个数（现程序是统计0、1和空格的个数）*/

#include <stdio.h>

void main ()

{
	int i=0,j=0,kong=0,a;
	printf("input zifu:   ");
	for (;;)
	{
		a = getchar();
		if (a==48)
		{
			i=i+1;
		}	
		if (a==49)
		{
			j=j+1;
		}
		if (a==32)
		{
			++kong;
		}
		if (a==27)
		{
			break;
		}
	}
	getchar();
	printf("i=%d,j=%d,kong=%d\n",i,j,kong);
}
