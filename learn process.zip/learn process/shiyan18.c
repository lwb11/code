/*向数组中输入10个数，并将它们按从大到小的顺序排列*/

#include <stdio.h>

void main ()

{
	int a[10],b[10],i,k,j,*p;
	printf("input some number:  ");	
	void zuida (int a[],int n);        //记得数组函数定义时的格式	

	for (i=0;i<=9;i++)
	{
		scanf("%d",&a[i]);
	}

		p = &a[0];
		zuida(p,10);
#if(0)
	for (k=0;k<=9;k++)
	{
		printf("%d  ",b[k]);
	}
	printf("\n");
#endif
}

void zuida (int a[],int n)      //计算最大值
{
	int *p,i,j,k,max,hao,c[n];
	
	for (i=0;i<n;i++)
	{
		max = a[i];
		for (j=i;j<n;j++)
		{
			if (max<a[j])
			{
				max = a[j];
				hao = j;
			}
		}
		a[hao] = a[i];
		c[i] = max;
	}
	for (k=0;k<n;k++)
	{
		printf("%d ",c[k]);
	}
	printf("\n");
}
