/*输入五个数对其进行冒泡排序（从小到大）*/

#include <stdio.h>

void main()

{
	int a[4],i,j;
	printf("input number:   ");
	scanf("%d %d %d %d %d",&a[0],&a[1],&a[2],&a[3],&a[4]);
	for (i=0;i<5;i++)
	{
		if (a[i]>a[i+1])
		{
			j = a[i];
			a[i] = a[i+1];
			a[i+1] = j;
		}
	}
	printf("%d,%d,%d,%d,%d\n",a[0],a[1],a[2],a[3],a[4]);
}
