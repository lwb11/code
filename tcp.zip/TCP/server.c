/*仅支持单客户端的服务器*/

#include "dabao.h"

#define SERVER_PORT 6666

int main(int argc,char *argv[])
{
	int sfd,cfd,rn,i;
	struct sockaddr_in serveraddr,clientaddr;
	socklen_t client_addr_len;
	char buf[BUFSIZ],client_IP[1024];

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERVER_PORT);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	//inet_pton(AF_INET,"192.168.1.457",&serveraddr.sin_addr);

	sfd = Socket(AF_INET,SOCK_STREAM,0);
	
	Bind(sfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));
	
	Listen(sfd,128);

	client_addr_len = sizeof(clientaddr);

	cfd = Accept(sfd,(struct sockaddr *)&clientaddr,&client_addr_len);

	printf("client ip:%s,client port:%d\n",
	inet_ntop(AF_INET,&clientaddr.sin_addr.s_addr,client_IP,sizeof(client_IP)),ntohs(clientaddr.sin_port));

	while(1)
	{
		rn = Read(cfd,buf,sizeof(buf));
		
		if (rn == 0){
			printf("the client has been closed.\n");
			break;
		}

		printf("%s\n",buf);
	//	Write(STDOUT_FILENO,buf,rn);      //回写到电脑屏幕上 

		for (i=0;i<rn;i++)
		{
			buf[i] = toupper(buf[i]);
		}
		Write(cfd,buf,rn); 
	}
	Close(sfd);
	Close(cfd);

	return 0;
}
