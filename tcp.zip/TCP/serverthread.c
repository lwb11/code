/*多线程并发服务器(线程不是很理解)*/

#include "dabao.h"

#define SERVER_PORT 6666
#define MAXLINE 8192

struct s_info        //定义一个结构体, 将地址结构跟cfd 捆绑
{     
    struct sockaddr_in clientaddr;
    int cfd;
};

void *do_work(void *arg)
{
    int n,i;
    struct s_info *ts = (struct s_info*)arg;
    char buf[MAXLINE];
    char str[INET_ADDRSTRLEN];

    while (1) 
    {
        n = Read(ts->cfd, buf, MAXLINE);       //读客户端
        if (n == 0) 
        {
            printf("the client port:%d has been closed.\n",ntohs((*ts).clientaddr.sin_port));
            Close(ts->cfd);
            break;          //跳出循环，关闭cfd
        }
    printf("received from %s at PORT %d\n",
    inet_ntop(AF_INET, &(*ts).clientaddr.sin_addr, str, sizeof(str)),ntohs((*ts).clientaddr.sin_port));   //打印客户端信息
    
    printf("%s\n",buf);
    
    for (i = 0; i < n; i++)
    {
        buf[i] = toupper(buf[i]);
    }

    Write(ts->cfd, buf, n);
    }  
    Close(ts->cfd);

    return 0;
}

int main(int argc,char *argv[])
{
    int lfd,cfd;
    int i = 0;
    pthread_t tid;

    struct s_info ts[256];

    struct sockaddr_in serveraddr,clientaddr;
    bzero(&serveraddr,sizeof(serveraddr));     //将地址结构清零

    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(SERVER_PORT);
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

    lfd = Socket(AF_INET,SOCK_STREAM,0);

    int opt = 1;         // 设置端口复用,避免服务器先于客户顿关闭，再启动时的等待时间
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));

    Bind(lfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));

    Listen(lfd,128);

    socklen_t client_addr_len = sizeof(clientaddr);

    while(1)
    {
        cfd = Accept(lfd,(struct sockaddr *)&clientaddr,&client_addr_len);

        ts[i].clientaddr = clientaddr;
        ts[i].cfd = cfd;

        pthread_create(&tid,NULL,do_work,(void *)&ts[i]);       //参3子线程创建成功的回调函数
        pthread_detach(tid);                  //子线程分离，防止僵尸线程产生

        i++;
    }

    return 0;
}
