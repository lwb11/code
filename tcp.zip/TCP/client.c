#include "dabao.h"

#define SERVER_PORT 6666
#define MAXSIZE 100

int main(int argc,char *argv[])
{
	int cfd,rn;
	char buf[MAXSIZE];
//	char str[100];

	struct sockaddr_in serveraddr;

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET,"127.0.0.1",&serveraddr.sin_addr);
	
	cfd = Socket(AF_INET,SOCK_STREAM,0);
	
	Connect(cfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));

    while(fgets(buf,MAXSIZE,stdin) != NULL)
	{
	//	scanf("%s\n",buf);
		printf("发送的内容:%s",buf);
		
		Write(cfd,buf,strlen(buf));
		rn = Read(cfd,buf,sizeof(buf));

		Write(STDOUT_FILENO,buf,rn);         //回写到电脑屏幕上     
	}
	Close(cfd);

	return 0;
}
