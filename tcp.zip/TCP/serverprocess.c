/*多进程并发服务器*/

#include "dabao.h"

#define SERVER_PORT 6666

int main(int argc,char *argv[])
{
    int lfd,cfd,i,ret;
    pid_t pid;
    //pid_t pid2;
    socklen_t client_addr_len;
    char buf[BUFSIZ],client_IP[1024];

    struct sockaddr_in serveraddr,clientaddr;
    bzero(&serveraddr,sizeof(serveraddr));   //将地址结构清零

    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(SERVER_PORT);
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

    lfd = Socket(AF_INET,SOCK_STREAM,0);

    int opt = 1;         // 设置端口复用,避免服务器先于客户顿关闭，再启动时的等待时间
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));

    Bind(lfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));

    Listen(lfd,128);

    client_addr_len = sizeof(clientaddr);

    while(1)
    {
        cfd = Accept(lfd,(struct sockaddr *)&clientaddr,&client_addr_len);

        printf("client ip:%s,client port:%d\n",
        inet_ntop(AF_INET,&clientaddr.sin_addr.s_addr,client_IP,sizeof(client_IP)),ntohs(clientaddr.sin_port));

        pid = fork();
        if (pid == 0)
        {
            Close(lfd);
            break;
        }
        else if (pid > 0)
        {
           waitpid(0,NULL,WNOHANG);      //用于回收子进程，防止变成僵尸进程
         
            Close(cfd);
            continue;
        }
        else
        {
            perr_exit("proess error");
        }
    }
    if (pid == 0)
    {
        while (1)
        {
            ret = Read(cfd,buf,sizeof(buf));
            if (ret == 0){
			    printf("the client port:%d has been closed.\n",ntohs(clientaddr.sin_port));
                Close(cfd);
			    break;
		    }

            printf("the message form prot %d is:%s\n",ntohs(clientaddr.sin_port),buf);

            for (i=0;i<ret;i++)
		    {
			    buf[i] = toupper(buf[i]);
	    	}
            Write(cfd,buf,ret);
        }
    }

    return 0;
}


