/*多路I/O转接服务器(select实现)*/

#include "dabao.h"

#define SERVER_PORT 6666
#define SET_SIZE 1024

int main(int argc,char *argv[])
{
	int lfd,cfd,sfd,ret,i,j,r,mask = -1;
	int maxfd = 0;
	char buf[BUFSIZ],client_IP[SET_SIZE],client[SET_SIZE];

	for (i = 0;i < SET_SIZE;i++){           //初始化文件描述符数组
		client[i] = mask;
	}

	struct sockaddr_in serveraddr,clientaddr;
	bzero(&serveraddr,sizeof(serveraddr));   //将地址结构清零

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERVER_PORT);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

	lfd = Socket(AF_INET,SOCK_STREAM,0);
	maxfd = lfd;

	int opt = 1;         // 设置端口复用,避免服务器先于客户顿关闭，再启动时的等待时间
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));

	Bind(lfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));

	Listen(lfd,128);

	fd_set rset,allset;

	FD_ZERO(&allset);    // 将读监听集合清空

	FD_SET(lfd,&allset);  //将lfd添加到读集合中

	socklen_t client_addr_len = sizeof(clientaddr);

	while(1){
		rset = allset;       //保存监听集合；

		ret = select(maxfd+1,&rset,NULL,NULL,NULL);   //监听文件描述符集合对应的事件
		//printf("检查ret:%d\n",ret);

		if (ret < 0){
			perr_exit("select error");
		}
		else {     
			if (FD_ISSET(lfd,&rset)){     //  判断文件描述符是否在监听集合中，1——在，0——不在
				cfd = Accept(lfd,(struct sockaddr *)&clientaddr,&client_addr_len);
        		printf("client ip:%s,client port:%d\n",
        		inet_ntop(AF_INET,&clientaddr.sin_addr.s_addr,client_IP,sizeof(client_IP)),ntohs(clientaddr.sin_port));

				for (i = 0;i < SET_SIZE; i++){       //查找数组中没有放文件描述符的位置
					if (client[i] < 0){
						client[i] = cfd;                    //将新生成的文将描述符放入数组中
						break;
					}
					if (i == SET_SIZE){
						perr_exit("too many client");
					}
				}

				FD_SET(cfd,&allset);     //将新创建的文件描述符添加到读集合中

				if (maxfd < cfd){           //判断当下文件描述符是否为最大文件描述符
					maxfd = cfd;      
				}

				if (i > mask){                //将文件描述符的标号进行移动，保证mask总是存的数组的最后一个
					mask = i;
				}

				if (0 == --ret){              //若只有请求连接的文件描述符产生，就继续监听
					continue;
				}
			}

			for (i = 0; i <= mask; i++){     //轮询，检测那个cfd有数据需要传输
				if ((sfd = client[i]) < 0){
					continue;
				}
				if (FD_ISSET(sfd,&rset)){            

            		r = Read(sfd,buf,sizeof(buf));
					//printf("检查r:%d\n",r);

            		if (r == 0){
			   			printf("the client port:%d has been closed.\n",ntohs(clientaddr.sin_port));
				
						FD_CLR(sfd,&allset);     //将无数据传输的文件描述符从读集合中移除掉
						client[i] = -1;
						Close(sfd);                   //关闭无数据传输的文件描述符
		    		}				
					else if (r > 0){               //主要实现的功能
            			printf("the message form prot %d is %s\n",ntohs(clientaddr.sin_port),buf);

            			for (j=0;j<r;j++)
		    			{
			    			buf[j] = toupper(buf[j]);
	    				}
            			Write(sfd,buf,r);
					}
				}	
			}
		}
	}
	Close(lfd);
	return 0;
}
