/*多路I/O转接服务器(epoll实现)*/

#include "dabao.h"

#define SERVER_PORT 6666
#define SET_SIZE 1024

int main(int argc,char *argv[])
{
	int lfd,cfd,i,n,ret,m,j;
	char buf[BUFSIZ],client_IP[BUFSIZ];

	struct epoll_event tep,ep[SET_SIZE];           //tep: epoll_ctl参数;  ep[]: epoll_wait参数
	struct sockaddr_in serveraddr,clientaddr;
	bzero(&serveraddr,sizeof(serveraddr));         //将地址结构清零

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERVER_PORT);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

	lfd = Socket(AF_INET,SOCK_STREAM,0);

	int opt = 1;             // 设置端口复用,避免服务器先于客户顿关闭，再启动时的等待时间
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));

	Bind(lfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr));

	Listen(lfd,128);

	int epfd = epoll_create(SET_SIZE);          //创建监听模型，epfd指向红黑树的树根
	if (epfd == -1){                                     //出错判断
		perr_exit("epoll_create error");
	}

	tep.events = EPOLLIN;                           //初始化lfd的监听属性 
	tep.data.fd = lfd;

	m = epoll_ctl(epfd,EPOLL_CTL_ADD,lfd,&tep);   //将lfd添加到监听模型上，即红黑树
	if (m == -1){
		perr_exit("add_lfd error");
	}

	socklen_t client_addr_len = sizeof(clientaddr);

	while(1){
		ret = epoll_wait(epfd,ep,SET_SIZE,-1);          //进行监听
		if (ret == -1){
			perr_exit("epoll_wait error");
		}

		for (i = 0;i < ret;i++){
			if (!(ep[i].events & EPOLLIN)){   //判断是否为读事件；不是——进行循环；是——执行下面语句
				continue;
			}

			if (ep[i].data.fd == lfd){        //判断是否为请求连接事件lfd
				cfd = Accept(lfd,(struct sockaddr *)&clientaddr,&client_addr_len);
				printf("client ip:%s,client port:%d\n",
        		inet_ntop(AF_INET,&clientaddr.sin_addr.s_addr,client_IP,sizeof(client_IP)),ntohs(clientaddr.sin_port));

				tep.events = EPOLLIN;      //初始化新连接事件cfd的属性       
				tep.data.fd = cfd;

				m = epoll_ctl(epfd,EPOLL_CTL_ADD,cfd,&tep);      //并将新连接事件cfd添加到红黑树上
				if (m == -1){
					perr_exit("add_cfd error");
				}
			}
			else{       
				n = Read(ep[i].data.fd,buf,sizeof(buf));
           		if (n == 0){
					m = epoll_ctl(epfd,EPOLL_CTL_DEL,ep[i].data.fd,NULL);     //将无数据传输的文件描述符从红黑树上摘除
					if (m == -1){
						perr_exit("del_cfd error");
					}
					printf("the client port:%d has been closed.\n",ntohs(clientaddr.sin_port));
					Close(ep[i].data.fd);       //【注意！】要先摘除文件描述符再进行关闭，否则摘除时会出错
		    	}				
				else{
            		printf("the message form prot %d is:%s\n",ntohs(clientaddr.sin_port),buf);

	            	for (j=0;j<n;j++)	
			    	{
				    	buf[j] = toupper(buf[j]);
		    		}
    	        	Write(ep[i].data.fd,buf,n);
				}
			}
		}
	}
	Close(lfd);
	Close(epfd);
	
	return 0;
}